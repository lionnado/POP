#!/usr/bin/env bash
# One-shot setup for Termux:  bash setup.sh
set -e
cd "$(dirname "${BASH_SOURCE[0]}")"
if command -v pkg >/dev/null; then
  pkg update -y
  pkg install -y clang make ncurses ncurses-utils python rust binutils || pkg install -y clang make ncurses ncurses-utils python
fi
bash scripts/build.sh
bash scripts/install.sh
echo
echo "Setup complete.  Type:  POP"
