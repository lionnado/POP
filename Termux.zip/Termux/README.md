# POP - multi-OS terminal simulator for Termux

Type `POP` and tap **Linux**, **Windows** or **Mac**. The button expands with a description;
tap it again (or press Enter) to run the loading sequence and enter that environment.
Type `exit` inside an environment to return to the menu. Saved state lives in `~/.pop`.

## Install (inside Termux)
    unzip Termux.zip && cd Termux
    bash setup.sh        # installs clang, ncurses, python, rust; builds; links POP
    POP

If `rust` cannot be installed, POP still works using a Python fallback engine.
Run `POP linux|windows|mac` to skip the menu, `POP --reset` to wipe saved state.

## Layout
| Path | Language | Role |
|---|---|---|
| `src/ui/pop_ui.cpp` | C++ / ncurses | touch menu, expand animation, loading screen |
| `src/sys/popsys.c` | C | GRUB / UEFI / EFI firmware boot screens |
| `rust/popcore/` | Rust | process table, scheduler noise, registry hive (std only) |
| `python/popos/` | Python | VFS, shell engine, Linux/Windows/macOS environments |
| `bin/POP`, `scripts/`, `setup.sh` | Bash | launcher, build, install |

Shared shell features (all OSes): pipes, `>` `>>`, `;` `&&`, globbing, TAB completion,
history, scripts, `help`, `pop-info`, `pop-reset`, `reboot`/`poweroff`.

## Environments (simulations, not real OS code)
* **Linux** - FHS tree, kernel boot log, systemd-style units (`systemctl`), `/proc`, `apt`/`dpkg`,
  `sudo`, `ps/top/free/df`, bash-like shell. Modelled on Linux conventions, not the kernel source.
* **Windows** - `C:\` with Windows\System32, Program Files, Users; cmd.exe plus PowerShell
  (`powershell` / `exit`); `reg`, `tasklist`, `taskkill`, `winget`, `systeminfo`, `ipconfig`.
* **Mac** - /Applications, /Library, /System, /Users; zsh prompt; `brew`, `sw_vers`,
  `defaults`, `launchctl`, `system_profiler`, `pbcopy`.

## Extending
Add a command by writing `def c_name(self, args, stdin)` on an OS shell class (return text or
raise `CmdError`). Add a new OS: subclass `Shell`/`PosixShell`, provide `generate()` and `boot()`,
register it in `boot.get_class()`, and add an entry to `OSES[]` in `pop_ui.cpp`.
