"""POP - a multi-OS terminal simulator for Termux."""
__version__ = "1.0.0"
