"""POP macOS: Darwin-style layout, zsh prompt, brew, sw_vers, defaults, launchctl."""
import time

from .posix import PosixShell
from .shell import CmdError, col, nap, parse_flags, progress_bar

BIN = "POPBIN"
PRODUCT, VERSION, BUILD, KERNEL = "macOS", "14.5", "23F79", "23.5.0"
APPS = ["Safari", "Mail", "Notes", "Calendar", "Messages", "Photos", "Music", "Preview", "TextEdit", "Calculator", "Terminal", "Finder"]
BREW = {"wget": ("Internet file retriever", "1.24.5"), "htop": ("Improved top (interactive process viewer)", "3.3.0"),
        "tree": ("Display directories as trees", "2.1.3"), "git": ("Distributed revision control system", "2.46.0"),
        "python@3.12": ("Interpreted, interactive, object-oriented language", "3.12.4"), "node": ("Platform built on V8", "22.5.1"),
        "neofetch": ("Fast, highly customisable system info script", "7.1.0"), "jq": ("Lightweight and flexible command-line JSON processor", "1.7.1")}
ZPROFILE = "# ~/.zprofile\neval \"$(/opt/homebrew/bin/brew shellenv)\"\n"
ZSHRC = "# ~/.zshrc\nexport EDITOR=nano\nalias ll='ls -lah'\n"


def info_plist(name):
    return (f'<?xml version="1.0" encoding="UTF-8"?>\n<plist version="1.0"><dict>\n  <key>CFBundleName</key><string>{name}</string>\n'
            f'  <key>CFBundleIdentifier</key><string>com.pop.{name.lower()}</string>\n  <key>CFBundleShortVersionString</key><string>{VERSION}</string>\n</dict></plist>\n')


class MacShell(PosixShell):
    os_name = "mac"
    case_insensitive = True
    shell_name = "zsh"
    group = "staff"
    uid = 501
    home_dir = "/Users/user"
    uname_info = ("Darwin", "Mac.local", KERNEL, f"Darwin Kernel Version {KERNEL}: Wed May  1 20:12:58 PDT 2024; root:xnu-10063.121.3~5/RELEASE_ARM64_T6000", "arm64")
    clip = ""

    @classmethod
    def generate(cls, vfs):
        yield "Creating the Darwin root (/System, /Library, /Applications, /Users)"
        vfs.populate("/", {d: {} for d in "Applications Library System Users Volumes bin sbin usr opt cores dev etc tmp var private".split()})
        for d in ("System/Library/CoreServices System/Library/Frameworks System/Library/Extensions System/Applications System/Volumes "
                  "Library/Application\\ Support Library/Preferences Library/LaunchDaemons Library/LaunchAgents Library/Fonts Library/Logs Library/Caches "
                  "Library/Developer/CommandLineTools Applications/Utilities usr/bin usr/lib usr/libexec usr/sbin usr/share usr/local/bin "
                  "opt/homebrew/bin opt/homebrew/Cellar opt/homebrew/etc private/etc private/var private/tmp var/log var/db Volumes/Macintosh\\ HD").split():
            vfs.mkdir("/" + d.replace("\\ ", " "), parents=True, owner="root")
        yield "Installing system applications and bundles"
        for app in APPS:
            base = "/Applications" if app == "Safari" else "/System/Applications" if app in ("Mail", "Notes", "Calendar", "Messages", "Photos", "Music", "Preview", "TextEdit", "Calculator") else "/Applications/Utilities"
            if app == "Finder":
                base = "/System/Library/CoreServices"
            vfs.populate(f"{base}/{app}.app/Contents", {"Info.plist": info_plist(app), "MacOS": {app: BIN + " " + app}, "Resources": {}, "_CodeSignature": {}}, owner="root")
        vfs.write("/System/Library/CoreServices/SystemVersion.plist",
                  f'<plist><dict><key>ProductName</key><string>{PRODUCT}</string><key>ProductVersion</key><string>{VERSION}</string><key>ProductBuildVersion</key><string>{BUILD}</string></dict></plist>\n', owner="root")
        yield "Writing /bin, /usr/bin and system utilities"
        for b in "ls cat cp mv rm mkdir rmdir echo pwd date chmod sleep sh zsh bash ps kill dd df".split():
            vfs.write(f"/bin/{b}", BIN + f" {b}", mode=0o755, owner="root")
        for b in "grep find head tail wc sort uniq env id whoami uname open say defaults sw_vers diskutil launchctl pbcopy pbpaste mdfind caffeinate xcode-select system_profiler softwareupdate scutil".split():
            vfs.write(f"/usr/bin/{b}", BIN + f" {b}", mode=0o755, owner="root")
        vfs.write("/opt/homebrew/bin/brew", BIN + " brew", mode=0o755, owner="user")
        yield "Configuring /etc, /private and launchd"
        etc = {"hosts": "127.0.0.1\tlocalhost\n255.255.255.255\tbroadcasthost\n::1\tlocalhost\n", "shells": "/bin/bash\n/bin/zsh\n/bin/sh\n",
               "paths": "/usr/local/bin\n/usr/bin\n/bin\n/usr/sbin\n/sbin\n", "zshrc": "# system-wide zsh config\n", "passwd": "root:*:0:0:System Administrator:/var/root:/bin/sh\nuser:*:501:20:POP User:/Users/user:/bin/zsh\n"}
        vfs.populate("/etc", etc)
        vfs.populate("/Library/LaunchDaemons", {"com.pop.syslogd.plist": info_plist("syslogd")})
        vfs.write("/var/log/system.log", "", owner="root")
        yield "Creating the home folder (/Users/user)"
        vfs.populate("/Users/user", {d: {} for d in "Desktop Documents Downloads Movies Music Pictures Public Applications".split()}, owner="user")
        vfs.populate("/Users/user/Library", {"Preferences": {}, "Caches": {}, "Logs": {}, "Application Support": {}, "Keychains": {}}, owner="user")
        vfs.write("/Users/user/.zshrc", ZSHRC, owner="user")
        vfs.write("/Users/user/.zprofile", ZPROFILE, owner="user")
        vfs.write("/Users/user/Documents/README.txt", "Welcome to POP macOS.\nTry: sw_vers, brew install neofetch, defaults read NSGlobalDomain, launchctl list\n", owner="user")
        vfs.populate("/Users", {"Shared": {}}, owner="root")
        yield "macOS is ready"

    def boot(self, first):
        self.env.update({"HOME": "/Users/user", "USER": "user", "LOGNAME": "user", "SHELL": "/bin/zsh", "PWD": self.cwd, "TERM": "xterm-256color",
                         "PATH": "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin", "LANG": "en_US.UTF-8", "TMPDIR": "/var/folders/zz/tmp/T/"})
        self.host = "Mac"
        self.aliases.update({"ll": "ls -lah", ".": "source"})
        self.core.request("INIT", 1, 0, 2)
        self.spawn("kernel_task", 0, 600000)
        self.spawn("launchd", 0, 9000)
        for n, m in [("logd", 14000), ("UserEventAgent", 6000), ("fseventsd", 9500), ("mds", 52000), ("configd", 11000), ("WindowServer", 150000),
                     ("loginwindow", 21000), ("Dock", 58000), ("SystemUIServer", 30000), ("Finder", 120000), ("Terminal", 84000)]:
            self.spawn(n, 1, m)
        self.pid = self.spawn("zsh", 1, 5200)
        print(f"{col('Darwin Boot Loader', 'bold')}  -  EFI System Partition")
        for m in ("Loading XNU kernel", "Mounting APFS volume 'Macintosh HD'", "Starting launchd", "Starting WindowServer", "Loading user session"):
            progress_bar(f"  {m:<40}", 14, 0.03)
        print(f"\nLast login: {time.strftime('%a %b %e %H:%M:%S')} on ttys000")

    def prompt(self):
        c = self.cwd
        short = "~" if c == self.env["HOME"] else "/" if c == "/" else c.rsplit("/", 1)[-1]
        return f"{col(self.user + '@' + self.host, 'green')} {col(short, 'cyan')} {'#' if self.user == 'root' else '%'} "

    def notfound(self, n):
        return f"zsh: command not found: {n}"

    def c_date(self, a, i):
        return time.strftime("%a %b %e %H:%M:%S %Z %Y")

    def c_uptime(self, a, i):
        return f"{time.strftime('%H:%M')}  up {self.uptime_s() // 60} mins, 1 user, load averages: 1.20 1.10 1.05"

    def c_sw_vers(self, a, i):
        return f"ProductName:\t\t{PRODUCT}\nProductVersion:\t\t{VERSION}\nBuildVersion:\t\t{BUILD}"

    def c_scutil(self, a, i):
        return "Mac" if "--get" in a else ""

    def c_xcode_select(self, a, i):
        return "/Library/Developer/CommandLineTools" if "-p" in a else "xcode-select: error: invalid argument"

    def c_softwareupdate(self, a, i):
        return "Software Update Tool\n\nFinding available software\nNo new software available."

    def c_caffeinate(self, a, i):
        return ""

    def c_say(self, a, i):
        return ""

    def c_open(self, a, i):
        fl, r = parse_flags(a)
        for t in r:
            if t.startswith("http"):
                continue
            if not self.vfs.exists(self.inpath(t)):
                raise CmdError(f"The file {self.inpath(t)} does not exist.")
        return ""

    def c_pbcopy(self, a, i):
        MacShell.clip = i or ""

    def c_pbpaste(self, a, i):
        return MacShell.clip

    def c_mdfind(self, a, i):
        q = a[-1].lower() if a else ""
        return "\n".join(p for p, _ in self.vfs.walk("/Users") if q in p.lower().rsplit("/", 1)[-1])

    def c_df(self, a, i):
        fl, _ = parse_flags(a)
        if "h" in fl:
            return ("Filesystem        Size    Used   Avail Capacity  Mounted on\n/dev/disk3s1s1   460Gi    10Gi   310Gi     4%    /\n"
                    "/dev/disk3s6     460Gi   6.0Gi   310Gi     2%    /System/Volumes/VM\n/dev/disk3s5     460Gi   130Gi   310Gi    30%    /System/Volumes/Data")
        return "Filesystem   512-blocks      Used Available Capacity  Mounted on\n/dev/disk3s1s1  965595304  20972472 650000000     4%    /"

    def c_diskutil(self, a, i):
        if a and a[0] == "list":
            return ("/dev/disk0 (internal, physical):\n   #:                       TYPE NAME                    SIZE       IDENTIFIER\n"
                    "   0:      GUID_partition_scheme                        *494.4 GB   disk0\n   1:             Apple_APFS_ISC Container disk1         524.3 MB   disk0s1\n"
                    "   2:                 Apple_APFS Container disk3         494.4 GB   disk0s2")
        raise CmdError("Usage: diskutil <verb> <options>")

    def c_launchctl(self, a, i):
        if a and a[0] == "list":
            return "PID\tStatus\tLabel\n" + "\n".join(f"{p[0]}\t0\tcom.apple.{p[4]}" for p in self.procs())
        raise CmdError("Usage: launchctl list")

    def c_system_profiler(self, a, i):
        t, u, f = (int(x) for x in self.core.request("MEM").split("\t"))
        if a and a[0] == "SPHardwareDataType":
            return (f"Hardware:\n\n    Hardware Overview:\n\n      Model Name: MacBook Pro\n      Chip: Apple M3 Pro\n      Total Number of Cores: 12\n"
                    f"      Memory: {t // 1048576} GB\n      System Firmware Version: 10151.121.1\n      Serial Number (system): POPSIM0001\n")
        return (f"Software:\n\n    System Software Overview:\n\n      System Version: {PRODUCT} {VERSION} ({BUILD})\n      Kernel Version: Darwin {KERNEL}\n"
                f"      Boot Volume: Macintosh HD\n      Computer Name: Mac\n      User Name: POP User (user)\n      Time since boot: {self.uptime_s() // 60} minutes\n")

    def c_defaults(self, a, i):
        if len(a) < 2:
            raise CmdError("Usage: defaults [-currentHost | -host <hostname>] read | write | delete ...")
        act, dom = a[0], a[1]
        path = f"/Users/user/Library/Preferences/{dom}.plist"
        data = {}
        if self.vfs.exists(path):
            data = dict(l.split(" = ", 1) for l in self.vfs.read(path).splitlines() if " = " in l)
        if act == "read":
            if len(a) > 2:
                if a[2] not in data:
                    raise CmdError(f"The domain/default pair of ({dom}, {a[2]}) does not exist")
                return data[a[2]]
            if not data and dom not in ("NSGlobalDomain", "-g"):
                raise CmdError(f"Domain {dom} does not exist")
            return "{\n" + "".join(f'    {k} = {v};\n' for k, v in data.items()) + "}"
        if act == "write" and len(a) >= 4:
            data[a[2]] = a[-1]
            self.vfs.write(path, "".join(f"{k} = {v}\n" for k, v in data.items()), owner=self.user)
            return ""
        if act == "delete" and len(a) > 2:
            data.pop(a[2], None)
            self.vfs.write(path, "".join(f"{k} = {v}\n" for k, v in data.items()), owner=self.user)
            return ""
        raise CmdError("Unknown or unsupported defaults command")

    # --------------------------------------------------------- Homebrew
    def _brewed(self):
        p = "/opt/homebrew/etc/pop-installed"
        return [l for l in self.vfs.read(p).splitlines() if l] if self.vfs.exists(p) else []

    def c_brew(self, a, i):
        if not a:
            return "Example usage:\n  brew search TEXT|/REGEX/\n  brew info [FORMULA...]\n  brew install FORMULA...\n  brew uninstall FORMULA...\n  brew list"
        act, pk = a[0], a[1:]
        inst = self._brewed()
        if act == "--version":
            return "Homebrew 4.3.12"
        if act == "list":
            return "\n".join(inst)
        if act == "search":
            return "==> Formulae\n" + "\n".join(k for k in BREW if not pk or pk[0] in k)
        if act == "update":
            return "Already up-to-date."
        if act == "info":
            if not pk or pk[0] not in BREW:
                raise CmdError(f"Error: No available formula with the name \"{pk[0] if pk else ''}\".")
            d, v = BREW[pk[0]]
            return f"==> {pk[0]}: stable {v}\n{d}\n{'Installed' if pk[0] in inst else 'Not installed'}"
        if act == "install":
            for n in pk:
                if n not in BREW:
                    raise CmdError(f"Error: No available formula with the name \"{n}\".")
                if n in inst:
                    print(f"Warning: {n} {BREW[n][1]} is already installed and up-to-date.")
                    continue
                print(f"==> Fetching {n}\n==> Downloading https://ghcr.io/v2/homebrew/core/{n}/blobs/sha256:pop")
                progress_bar("######", 24, 0.03)
                print(f"==> Pouring {n}--{BREW[n][1]}.arm64_sonoma.bottle.tar.gz")
                self.vfs.write(f"/opt/homebrew/bin/{n.split('@')[0]}", BIN + f" {n}", mode=0o755, owner="user")
                self.vfs.mkdir(f"/opt/homebrew/Cellar/{n}/{BREW[n][1]}", parents=True, owner="user")
                self.vfs.write("/opt/homebrew/etc/pop-installed", n + "\n", append=True, owner="user")
                print(f"🍺  /opt/homebrew/Cellar/{n}/{BREW[n][1]}: 12 files, 3.1MB")
            return ""
        if act in ("uninstall", "remove"):
            for n in pk:
                if n not in inst:
                    raise CmdError(f"Error: No such keg: /opt/homebrew/Cellar/{n}")
                inst.remove(n)
                self.vfs.remove(f"/opt/homebrew/bin/{n.split('@')[0]}")
                print(f"Uninstalling /opt/homebrew/Cellar/{n}... (12 files, 3.1MB)")
            self.vfs.write("/opt/homebrew/etc/pop-installed", "".join(x + "\n" for x in inst), owner="user")
            return ""
        raise CmdError(f"Error: Unknown command: {act}")

    def c_neofetch(self, a, i):
        if "neofetch" not in self._brewed():
            raise CmdError("zsh: command not found: neofetch")
        t, u, f = (int(x) for x in self.core.request("MEM").split("\t"))
        logo = ["       .:'", "    _ :'_", " .'`_`-'_``.", ":________.-'", ":_______:", " :_______`-;", "  `._.-._.'"]
        info = ["user@Mac", "--------", f"OS: {PRODUCT} {VERSION} arm64", "Host: MacBook Pro", f"Kernel: Darwin {KERNEL}", f"Uptime: {self.uptime_s() // 60} mins",
                "Shell: zsh 5.9", f"Memory: {u // 1024}MiB / {t // 1024}MiB"]
        return "\n".join(f"{col(logo[k] if k < len(logo) else ' ' * 13, 'green'):<24}  {info[k] if k < len(info) else ''}" for k in range(max(len(logo), len(info))))

    def c_htop(self, a, i):
        if "htop" not in self._brewed():
            raise CmdError("zsh: command not found: htop")
        return self.c_ps(["aux"], i)

    def c_shutdown(self, a, i):
        return self.c_poweroff(a, i)

    def c_sudo(self, a, i):
        if not a:
            raise CmdError("usage: sudo -h | -K | -k | -V")
        return self.dispatch(a, i)
