"""Boot orchestration: firmware screen, first-boot OS generation, shell, persistence."""
import os
import subprocess
import sys

from .core import make_core
from .shell import col, nap
from .vfs import VFS


def get_class(name):
    if name == "linux":
        from .linux import LinuxShell
        return LinuxShell
    if name == "windows":
        from .windows import WindowsShell
        return WindowsShell
    if name == "mac":
        from .macos import MacShell
        return MacShell
    raise SystemExit(f"popos: unknown OS '{name}' (use linux, windows or mac)")


def bar(i, n, msg, width=28):
    filled = i * width // n
    sys.stdout.write(f"\r  [{'#' * filled}{'.' * (width - filled)}] {i * 100 // n:3d}%  {msg:<62}")
    sys.stdout.flush()


def run(os_name, home=None):
    home = home or os.environ.get("POP_HOME") or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    cls = get_class(os_name)
    state_dir = os.path.expanduser("~/.pop")
    os.makedirs(state_dir, exist_ok=True)
    state = os.path.join(state_dir, f"{os_name}.json")
    core = make_core(home)

    popsys = os.path.join(home, "bin", "popsys")           # C firmware/bootloader simulation
    if os.path.isfile(popsys):
        subprocess.call([popsys, os_name])

    vfs = VFS(ci=cls.case_insensitive)
    first = not os.path.exists(state)
    if first:
        print(col(f"\nFirst boot: generating the {os_name} environment...\n", "cyan"))
        stages = list(cls.generate(vfs))                   # generator does its work as we iterate
        # generate() is lazy: re-create to animate with the real stage names
        vfs = VFS(ci=cls.case_insensitive)
        names = []
        for k, stage in enumerate(cls.generate(vfs), 1):
            names.append(stage)
            bar(k, len(stages), stage)
            nap(0.35)
        bar(len(stages), len(stages), "Done")
        print("\n")
    else:
        vfs.load(state)

    while True:
        shell = cls(vfs, core, cls.home_dir)
        shell.state_path = state
        shell.reg_path = os.path.join(state_dir, f"{os_name}.reg")
        try:
            shell.boot(first)
            first = False
            shell.loop()
        finally:
            vfs.save(state)
            if os_name == "windows":
                core.request("REGSAVE", shell.reg_path)
        if not shell.reboot:
            break
        print(col("\nRebooting...\n", "yellow"))
        nap(0.8)
    if hasattr(core, "close"):
        core.close()
    print(col(f"\n[POP] {os_name} powered off. Returning to menu.", "dim"))
    nap(0.6)
    return 0
