"""In-memory virtual filesystem shared by every POP OS environment.

Paths inside the VFS are always POSIX-style ("/Windows/System32").  The Windows
shell translates "C:\\Windows" <-> "/Windows"; Linux/macOS use them directly.
Case-insensitive lookup is available for Windows and macOS (APFS default).
"""
import json
import posixpath
import time


class FSError(Exception):
    def __init__(self, msg, path=""):
        super().__init__(msg)
        self.msg, self.path = msg, path


class Node:
    """One file ('f') or directory ('d')."""
    __slots__ = ("kind", "data", "children", "mode", "owner", "mtime")

    def __init__(self, kind, data="", mode=None, owner="user"):
        self.kind, self.data, self.owner, self.mtime = kind, data, owner, time.time()
        self.children = {} if kind == "d" else None
        self.mode = mode if mode is not None else (0o755 if kind == "d" else 0o644)

    def size(self):
        return 4096 if self.kind == "d" else len(self.data.encode())

    def dump(self):
        base = {"k": self.kind, "m": self.mode, "o": self.owner, "t": self.mtime}
        if self.kind == "d":
            base["c"] = {n: c.dump() for n, c in self.children.items()}
        else:
            base["d"] = self.data
        return base

    @staticmethod
    def load(d):
        n = Node(d["k"], d.get("d", ""), d["m"], d["o"])
        n.mtime = d["t"]
        if d["k"] == "d":
            n.children = {k: Node.load(v) for k, v in d["c"].items()}
        return n


class VFS:
    def __init__(self, ci=False):
        self.root = Node("d", owner="root")
        self.ci = ci            # case-insensitive lookups?
        self.providers = {}     # dynamic files: path -> callable returning str

    # ---- path helpers -------------------------------------------------
    @staticmethod
    def normalize(path, cwd="/"):
        if not path:
            path = cwd
        if not path.startswith("/"):
            path = cwd.rstrip("/") + "/" + path
        p = posixpath.normpath(path)
        return "/" + p.lstrip("/") if p.startswith("//") else p

    @staticmethod
    def parts(path):
        return [p for p in path.split("/") if p]

    def _find(self, name, children):
        if name in children:
            return name
        if self.ci:
            low = name.lower()
            for k in children:
                if k.lower() == low:
                    return k
        return None

    def canon(self, path):
        """Return path with the real on-disk capitalisation."""
        node, out = self.root, []
        for part in self.parts(path):
            k = self._find(part, node.children) if node.kind == "d" else None
            if k is None:
                out.append(part)
                node = Node("f")
            else:
                out.append(k)
                node = node.children[k]
        return "/" + "/".join(out)

    # ---- queries --------------------------------------------------------
    def get(self, path):
        node = self.root
        for part in self.parts(path):
            if node.kind != "d":
                raise FSError("Not a directory", path)
            k = self._find(part, node.children)
            if k is None:
                raise FSError("No such file or directory", path)
            node = node.children[k]
        return node

    def exists(self, path):
        try:
            self.get(path)
            return True
        except FSError:
            return False

    def _parent(self, path):
        parts = self.parts(path)
        if not parts:
            raise FSError("Invalid path", path)
        parent = self.get("/" + "/".join(parts[:-1]))
        if parent.kind != "d":
            raise FSError("Not a directory", path)
        return parent, parts[-1]

    def walk(self, path):
        """Depth-first (path, node) pairs, starting with path itself."""
        node = self.get(path)
        yield path, node
        if node.kind == "d":
            for name in sorted(node.children, key=str.lower):
                yield from self.walk(path.rstrip("/") + "/" + name)

    # ---- mutation -----------------------------------------------------
    def mkdir(self, path, parents=False, owner="user"):
        parts, node = self.parts(path), self.root
        for i, part in enumerate(parts):
            k = self._find(part, node.children)
            last = i == len(parts) - 1
            if k is None:
                if not last and not parents:
                    raise FSError("No such file or directory", path)
                node.children[part] = Node("d", owner=owner)
                node = node.children[part]
            else:
                node = node.children[k]
                if node.kind != "d":
                    raise FSError("Not a directory", path)
                if last and not parents:
                    raise FSError("File exists", path)
        return node

    def write(self, path, data, append=False, mode=None, owner="user"):
        parent, name = self._parent(path)
        k = self._find(name, parent.children)
        if k is None:
            n = parent.children[name] = Node("f", data, mode, owner)
        else:
            n = parent.children[k]
            if n.kind == "d":
                raise FSError("Is a directory", path)
            n.data = n.data + data if append else data
            n.mtime = time.time()
        return n

    def read(self, path):
        prov = self.providers.get(path.lower() if self.ci else path)
        n = self.get(path)
        if n.kind == "d":
            raise FSError("Is a directory", path)
        return prov() if prov else n.data

    def add_provider(self, path, fn, owner="root"):
        if not self.exists(path):
            self.write(path, "", owner=owner)
        self.providers[path.lower() if self.ci else path] = fn

    def remove(self, path, recursive=False):
        parent, name = self._parent(path)
        k = self._find(name, parent.children)
        if k is None:
            raise FSError("No such file or directory", path)
        if parent.children[k].kind == "d" and parent.children[k].children and not recursive:
            raise FSError("Directory not empty", path)
        del parent.children[k]

    def copy(self, src, dst):
        clone = Node.load(self.get(src).dump())
        clone.mtime = time.time()
        parent, name = self._parent(dst)
        parent.children[name] = clone

    def move(self, src, dst):
        self.copy(src, dst)
        self.remove(src, True)

    def populate(self, base, tree, owner="root"):
        """Create a nested dict {name: str|dict} under base."""
        if base != "/" and not self.exists(base):
            self.mkdir(base, parents=True, owner=owner)
        for name, val in tree.items():
            p = base.rstrip("/") + "/" + name
            if isinstance(val, dict):
                self.populate(p, val, owner)
            else:
                self.write(p, val, mode=0o755 if val.startswith("POPBIN") else None, owner=owner)

    # ---- persistence --------------------------------------------------
    def save(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"ci": self.ci, "root": self.root.dump()}, f)

    def load(self, path):
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        self.ci, self.root = d["ci"], Node.load(d["root"])
