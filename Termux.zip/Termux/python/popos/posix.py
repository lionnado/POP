"""Shared POSIX-style commands used by the Linux and macOS environments."""
import fnmatch
import os
import posixpath
import re
import time

from .shell import Shell, CmdError, ExitShell, parse_flags, col, nap


def rwx(mode):
    s = ""
    for sh in (6, 3, 0):
        b = (mode >> sh) & 7
        s += ("r" if b & 4 else "-") + ("w" if b & 2 else "-") + ("x" if b & 1 else "-")
    return s


def hsize(n):
    v = float(n)
    for u in "BKMG":
        if v < 1024 or u == "G":
            return f"{int(v)}" if u == "B" else f"{v:.1f}{u}"
        v /= 1024


class PosixShell(Shell):
    shell_name = "sh"
    group = "user"
    uid = 1000
    uname_info = ("POP", "pop", "1.0", "#1", "arm64")

    # ------------------------------------------------------------ hooks
    def _inpath(self, p):
        if p == "~" or p.startswith("~/"):
            p = self.env["HOME"] + p[1:]
        return self.vfs.normalize(p, self.cwd)

    def expand(self, t):
        if "$(" in t:
            t = re.sub(r"\$\(([^()]*)\)", lambda m: self.capture(m.group(1)), t)

        def rep(m):
            k = m.group(1) or m.group(2)
            return str(self.status) if k == "?" else self.env.get(k, "")
        return re.sub(r"\$(?:\{(\w+)\}|(\w+|\?))", rep, t)

    def tilde(self, p):
        h = self.env["HOME"]
        return "~" + p[len(h):] if p == h or p.startswith(h + "/") else p

    def notfound(self, n):
        return f"{self.shell_name}: {n}: command not found"

    def dispatch(self, argv, stdin):
        m = re.match(r"^([A-Za-z_]\w*)=(.*)$", argv[0])
        if m and len(argv) == 1:                      # VAR=value
            self.env[m.group(1)] = m.group(2)
            return ""
        return super().dispatch(argv, stdin)

    # --------------------------------------------------------- navigation
    def c_pwd(self, a, i):
        return self.cwd

    def c_cd(self, a, i):
        t = a[0] if a else "~"
        if t == "-":
            t = self.env.get("OLDPWD", self.cwd)
        p = self.inpath(t)
        if self.vfs.get(p).kind != "d":
            raise CmdError(f"cd: {t}: Not a directory")
        self.env["OLDPWD"], self.cwd, self.env["PWD"] = self.cwd, self.vfs.canon(p), p

    def long_line(self, name, n, human):
        sz = hsize(n.size()) if human else n.size()
        t = time.strftime("%b %d %H:%M", time.localtime(n.mtime))
        nm = col(name, "blue") if n.kind == "d" and self.color else name
        return f"{'d' if n.kind == 'd' else '-'}{rwx(n.mode)} {2 if n.kind == 'd' else 1:>2} {n.owner:<8} {self.group:<8} {sz:>6} {t} {nm}"

    def c_ls(self, a, i):
        fl, paths = parse_flags(a)
        paths, out = paths or ["."], []
        for p in paths:
            n = self.vfs.get(self.inpath(p))
            if n.kind == "f":
                items = [(p, n)]
            else:
                names = sorted(n.children, key=str.lower)
                if "a" not in fl and "A" not in fl:
                    names = [x for x in names if not x.startswith(".")]
                items = [(x, n.children[x]) for x in names]
                if len(paths) > 1:
                    out.append(f"{p}:")
            if "l" in fl:
                if n.kind == "d":
                    out.append(f"total {sum(max(4, c.size() // 1024 * 4) for _, c in items)}")
                out += [self.long_line(nm, c, "h" in fl) for nm, c in items]
            elif "1" in fl or not self.color:
                out += [nm for nm, _ in items]
            else:
                plain = [nm for nm, _ in items]
                text = self.columns(plain)
                for nm, c in items:
                    if c.kind == "d":
                        text = re.sub(rf"(?<!\S){re.escape(nm)}(?!\S)", col(nm, "blue"), text, count=1)
                out.append(text)
        return "\n".join(x for x in out if x != "")

    def c_tree(self, a, i):
        fl, r = parse_flags(a)
        root, out, cnt = self.inpath(r[0] if r else "."), [r[0] if r else "."], [0, 0]

        def rec(path, prefix):
            n = self.vfs.get(path)
            names = [x for x in sorted(n.children, key=str.lower) if "a" in fl or not x.startswith(".")]
            for k, nm in enumerate(names):
                last, c = k == len(names) - 1, n.children[nm]
                out.append(prefix + ("└── " if last else "├── ") + nm)
                cnt[0 if c.kind == "d" else 1] += 1
                if c.kind == "d":
                    rec(path.rstrip("/") + "/" + nm, prefix + ("    " if last else "│   "))
        rec(root, "")
        out.append(f"\n{cnt[0]} directories, {cnt[1]} files")
        return "\n".join(out)

    def c_find(self, a, i):
        start = a[0] if a and not a[0].startswith("-") else "."
        name = typ = None
        for j, x in enumerate(a):
            if x in ("-name", "-iname") and j + 1 < len(a):
                name = a[j + 1]
            if x == "-type" and j + 1 < len(a):
                typ = a[j + 1]
        base, out = self.inpath(start), []
        for pth, nd in self.vfs.walk(base):
            if typ and (typ == "d") != (nd.kind == "d"):
                continue
            if name and not fnmatch.fnmatch(posixpath.basename(pth).lower(), name.lower()):
                continue
            rel = pth[len(base):].lstrip("/")
            out.append(start if not rel else start.rstrip("/") + "/" + rel)
        return "\n".join(out)

    def c_stat(self, a, i):
        out = []
        for f in a:
            n = self.vfs.get(self.inpath(f))
            t = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(n.mtime))
            kind = "directory" if n.kind == "d" else "regular file"
            out.append(f"  File: {f}\n  Size: {n.size():<10} Blocks: 8          IO Block: 4096   {kind}\n"
                       f"Access: ({n.mode:04o}/{'d' if n.kind == 'd' else '-'}{rwx(n.mode)})  Uid: ({self.uid}/{n.owner})\n"
                       f"Modify: {t}")
        return "\n".join(out)

    # --------------------------------------------------------- file ops
    def c_cat(self, a, i):
        fl, files = parse_flags(a)
        txt = "".join(self.read(f) for f in files) if files else (i or "")
        if "n" in fl:
            txt = "\n".join(f"{k:>6}\t{l}" for k, l in enumerate(txt.splitlines(), 1))
        return txt

    def c_echo(self, a, i):
        nl, esc = True, False
        while a and a[0] in ("-n", "-e", "-ne", "-en"):
            nl, esc = nl and "n" not in a[0], esc or "e" in a[0]
            a = a[1:]
        s = " ".join(a)
        if esc:
            s = s.encode().decode("unicode_escape")
        return s + ("\n" if nl else "")

    def c_mkdir(self, a, i):
        fl, r = parse_flags(a)
        if not r:
            raise CmdError("mkdir: missing operand")
        for d in r:
            self.vfs.mkdir(self.inpath(d), parents="p" in fl, owner=self.user)

    def c_rmdir(self, a, i):
        for d in a:
            n = self.vfs.get(self.inpath(d))
            if n.kind != "d":
                raise CmdError(f"rmdir: failed to remove '{d}': Not a directory")
            if n.children:
                raise CmdError(f"rmdir: failed to remove '{d}': Directory not empty")
            self.vfs.remove(self.inpath(d))

    def c_touch(self, a, i):
        for f in a:
            ap = self.inpath(f)
            if self.vfs.exists(ap):
                self.vfs.get(ap).mtime = time.time()
            else:
                self.vfs.write(ap, "", owner=self.user)

    def c_rm(self, a, i):
        fl, r = parse_flags(a)
        if not r and "f" not in fl:
            raise CmdError("rm: missing operand")
        rec = "r" in fl or "R" in fl
        for f in r:
            ap = self.inpath(f)
            if ap == "/" and rec:
                raise CmdError("rm: it is dangerous to operate recursively on '/'")
            if not self.vfs.exists(ap):
                if "f" in fl:
                    continue
                raise CmdError(f"rm: cannot remove '{f}': No such file or directory")
            if self.vfs.get(ap).kind == "d" and not rec:
                raise CmdError(f"rm: cannot remove '{f}': Is a directory")
            self.vfs.remove(ap, True)

    def _dst(self, r, cmd):
        if len(r) < 2:
            raise CmdError(f"{cmd}: missing destination file operand")
        dst = self.inpath(r[-1])
        isdir = self.vfs.exists(dst) and self.vfs.get(dst).kind == "d"
        if len(r) > 2 and not isdir:
            raise CmdError(f"{cmd}: target '{r[-1]}' is not a directory")
        return dst, isdir

    def c_cp(self, a, i):
        fl, r = parse_flags(a)
        dst, isdir = self._dst(r, "cp")
        for s in r[:-1]:
            sp = self.inpath(s)
            if self.vfs.get(sp).kind == "d" and not ({"r", "R"} & fl):
                raise CmdError(f"cp: -r not specified; omitting directory '{s}'")
            self.vfs.copy(sp, dst.rstrip("/") + "/" + posixpath.basename(sp) if isdir else dst)

    def c_mv(self, a, i):
        fl, r = parse_flags(a)
        dst, isdir = self._dst(r, "mv")
        for s in r[:-1]:
            sp = self.inpath(s)
            self.vfs.get(sp)
            self.vfs.move(sp, dst.rstrip("/") + "/" + posixpath.basename(sp) if isdir else dst)

    def c_chmod(self, a, i):
        if len(a) < 2:
            raise CmdError("chmod: missing operand")
        mode, files = a[0], a[1:]
        for f in files:
            n = self.vfs.get(self.inpath(f))
            if re.fullmatch(r"[0-7]{3,4}", mode):
                n.mode = int(mode, 8)
                continue
            m = re.fullmatch(r"([ugoa]*)([+\-=])([rwx]+)", mode)
            if not m:
                raise CmdError(f"chmod: invalid mode: '{mode}'")
            bits = sum({"r": 4, "w": 2, "x": 1}[c] for c in m.group(3))
            who = m.group(1) or "a"
            mask = 0
            for w, sh in (("u", 6), ("g", 3), ("o", 0)):
                if w in who or "a" in who:
                    mask |= bits << sh
            n.mode = n.mode | mask if m.group(2) == "+" else n.mode & ~mask if m.group(2) == "-" else mask

    def c_chown(self, a, i):
        return ""

    # -------------------------------------------------------- text tools
    def _nlines(self, a):
        n, rest, j = 10, [], 0
        while j < len(a):
            x = a[j]
            if x == "-n" and j + 1 < len(a):
                n, j = int(a[j + 1]), j + 2
                continue
            if re.fullmatch(r"-\d+", x):
                n = int(x[1:])
            elif x.startswith("-n") and x[2:].isdigit():
                n = int(x[2:])
            else:
                rest.append(x)
            j += 1
        return n, rest

    def c_head(self, a, i):
        n, f = self._nlines(a)
        return "".join((self.read(f[0]) if f else (i or "")).splitlines(True)[:n])

    def c_tail(self, a, i):
        n, f = self._nlines(a)
        return "".join((self.read(f[0]) if f else (i or "")).splitlines(True)[-n:] if n else [])

    def c_wc(self, a, i):
        fl, files = parse_flags(a)
        srcs = [(f, self.read(f)) for f in files] or [("", i or "")]
        out = []
        for name, t in srcs:
            vals = {"l": t.count("\n"), "w": len(t.split()), "c": len(t.encode())}
            keys = [k for k in "lwc" if k in fl] or list("lwc")
            out.append(" ".join(f"{vals[k]:>7}" for k in keys) + (f" {name}" if name else ""))
        return "\n".join(out)

    def c_sort(self, a, i):
        fl, files = parse_flags(a)
        lines = (self.read(files[0]) if files else (i or "")).splitlines()
        key = (lambda s: float(re.match(r"-?\d+\.?\d*", s).group()) if re.match(r"-?\d", s) else 0.0) if "n" in fl else None
        return "\n".join(sorted(lines, key=key, reverse="r" in fl))

    def c_uniq(self, a, i):
        fl, files = parse_flags(a)
        out, prev, cnt = [], None, 0
        for l in (self.read(files[0]) if files else (i or "")).splitlines() + [None]:
            if l == prev:
                cnt += 1
                continue
            if prev is not None:
                out.append(f"{cnt:>7} {prev}" if "c" in fl else prev)
            prev, cnt = l, 1
        return "\n".join(out)

    def c_grep(self, a, i):
        fl, r = parse_flags(a)
        if not r:
            raise CmdError("usage: grep [-icnvr] pattern [file ...]")
        pat = re.compile(r[0], re.I if "i" in fl else 0)
        srcs = []
        for f in r[1:]:
            ap = self.inpath(f)
            if "r" in fl and self.vfs.get(ap).kind == "d":
                srcs += [(p, self.vfs.read(p)) for p, nd in self.vfs.walk(ap) if nd.kind == "f"]
            else:
                srcs.append((f, self.read(f)))
        if not r[1:]:
            srcs = [(None, i or "")]
        show, out = len(srcs) > 1 or "r" in fl, []
        for name, txt in srcs:
            pre = f"{name}:" if show and name else ""
            hits = [(k, l) for k, l in enumerate(txt.splitlines(), 1) if bool(pat.search(l)) != ("v" in fl)]
            if "c" in fl:
                out.append(pre + str(len(hits)))
            else:
                out += [pre + (f"{k}:" if "n" in fl else "") + l for k, l in hits]
        return "\n".join(out)

    def c_basename(self, a, i):
        return posixpath.basename(a[0].rstrip("/")) if a else ""

    def c_dirname(self, a, i):
        return posixpath.dirname(a[0].rstrip("/")) or "." if a else ""

    def c_nano(self, a, i):
        """Tiny line editor so files can be created on a phone keyboard."""
        if not a:
            raise CmdError("usage: nano FILE")
        ap = self.inpath(a[0])
        lines = self.vfs.read(ap).splitlines() if self.vfs.exists(ap) else []
        print(col(f"[ POP editor: {a[0]} ]  '.' = save+quit, '.q' = abort, '.l' = list, '.d N' = delete line N", "cyan"))
        for k, l in enumerate(lines, 1):
            print(f"{k:>3}| {l}")
        while True:
            try:
                l = input(f"{len(lines) + 1:>3}| ")
            except EOFError:
                l = "."
            if l == ".":
                self.vfs.write(ap, "\n".join(lines) + ("\n" if lines else ""), owner=self.user)
                return f"Wrote {len(lines)} lines to {a[0]}"
            if l == ".q":
                return "Aborted."
            if l == ".l":
                print("\n".join(f"{k:>3}| {x}" for k, x in enumerate(lines, 1)))
            elif l.startswith(".d ") and l[3:].isdigit() and 0 < int(l[3:]) <= len(lines):
                del lines[int(l[3:]) - 1]
            else:
                lines.append(l)

    c_vi = c_vim = c_edit = c_nano

    # ------------------------------------------------------ shell / env
    def c_env(self, a, i):
        return "\n".join(f"{k}={v}" for k, v in sorted(self.env.items()) if not k.isdigit())

    c_printenv = c_env

    def c_export(self, a, i):
        for x in a:
            k, _, v = x.partition("=")
            if _:
                self.env[k] = v
        if not a:
            return "\n".join(f'declare -x {k}="{v}"' for k, v in sorted(self.env.items()) if not k.isdigit())

    def c_unset(self, a, i):
        for k in a:
            self.env.pop(k, None)

    def c_alias(self, a, i):
        if not a:
            return "\n".join(f"alias {k}='{v}'" for k, v in sorted(self.aliases.items()))
        for x in a:
            k, _, v = x.partition("=")
            if _:
                self.aliases[k] = v

    def c_which(self, a, i):
        out = []
        for n in a:
            hit = self.find_exe(n)
            if hit:
                out.append(hit[0])
            elif n in self.cmds:
                out.append(f"{n}: shell built-in command")
            else:
                raise CmdError(f"{n} not found")
        return "\n".join(out)

    def c_source(self, a, i):
        if not a:
            raise CmdError("source: filename argument required")
        self.run_script(self.read(a[0]), a[1:])

    def c_sh(self, a, i):
        if a and a[0] == "-c" and len(a) > 1:
            self.run_line(a[1])
        elif a:
            self.run_script(self.read(a[0]), a[1:])
        else:
            raise CmdError(f"{self.shell_name}: interactive sub-shells are not supported; use 'exit' to leave POP")

    c_bash = c_zsh = c_sh

    def c_history(self, a, i):
        return "\n".join(f"{k:>5}  {l}" for k, l in enumerate(self.history, 1))

    def c_man(self, a, i):
        raise CmdError(f"No manual entry for {a[0] if a else ''}")

    def c_true(self, a, i):
        return ""

    def c_false(self, a, i):
        raise CmdError("")

    def c_sleep(self, a, i):
        nap(min(float(a[0]) if a else 1, 5))

    # --------------------------------------------------------- identity
    def c_whoami(self, a, i):
        return self.user

    def c_id(self, a, i):
        return f"uid={self.uid}({self.user}) gid={self.uid}({self.group}) groups={self.uid}({self.group})"

    def c_hostname(self, a, i):
        return self.host

    def c_date(self, a, i):
        return time.strftime("%a %b %d %H:%M:%S %Z %Y")

    def c_uname(self, a, i):
        fl, _ = parse_flags(a)
        s, n, r, v, m = self.uname_info
        if "a" in fl:
            return f"{s} {n} {r} {v} {m}"
        parts = [x for k, x in (("s", s), ("n", n), ("r", r), ("v", v), ("m", m)) if k in fl]
        return " ".join(parts) if parts else s

    # --------------------------------------------------------- processes
    def c_ps(self, a, i):
        fl, _ = parse_flags(a)
        pr = self.procs()
        if "a" in fl and "u" in fl or "aux" in fl:
            rows = ["USER       PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND"]
            for p in pr:
                mem = int(p[3])
                rows.append(f"{'root' if int(p[1]) < 2 else self.user:<8} {p[0]:>5}  0.{int(p[3]) % 9}  {mem * 100 / 8388608:.1f} {mem * 4:>6} {mem:>5} ?        S{'+' if p[2] == 'R' else ' '}   {time.strftime('%H:%M')}   0:0{int(p[0]) % 9} {p[4]}")
            return "\n".join(rows)
        if "e" in fl or "f" in fl:
            rows = ["UID          PID    PPID  C STIME TTY          TIME CMD"]
            rows += [f"{'root' if int(p[1]) < 2 else self.user:<8} {p[0]:>7} {p[1]:>7}  0 {time.strftime('%H:%M')} ?        00:00:0{int(p[0]) % 9} {p[4]}" for p in pr]
            return "\n".join(rows)
        mine = [p for p in pr if p[0] == str(self.pid)]
        rows = ["    PID TTY          TIME CMD"]
        rows += [f"{p[0]:>7} pts/0    00:00:00 {p[4]}" for p in mine]
        rows.append(f"{int(pr[-1][0]) + 1:>7} pts/0    00:00:00 ps")
        return "\n".join(rows)

    def c_kill(self, a, i):
        _, r = parse_flags(a)
        if not r:
            raise CmdError("kill: usage: kill [-s sigspec | -n signum | -sigspec] pid | jobspec ... or kill -l")
        for pid in r:
            if not pid.isdigit():
                raise CmdError(f"{self.shell_name}: kill: {pid}: arguments must be process or job IDs")
            res = self.core.request("KILL", pid)
            if res.startswith("err\tprotected"):
                raise CmdError(f"{self.shell_name}: kill: ({pid}) - Operation not permitted")
            if res.startswith("err"):
                raise CmdError(f"{self.shell_name}: kill: ({pid}) - No such process")
        return ""

    def c_killall(self, a, i):
        _, r = parse_flags(a)
        hit = False
        for p in self.procs():
            if p[4] in r and self.core.request("KILL", p[0]) == "ok":
                hit = True
        if not hit:
            raise CmdError(f"{r[0] if r else ''}: no process found")
        return ""

    def c_uptime(self, a, i):
        m = self.uptime_s() // 60
        return f" {time.strftime('%H:%M:%S')} up {m} min,  1 user,  load average: 0.08, 0.03, 0.01"
