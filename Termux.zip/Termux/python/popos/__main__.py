"""Entry point:  python3 -m popos <linux|windows|mac>"""
import sys
from .boot import run

if __name__ == "__main__":
    target = sys.argv[1].lower() if len(sys.argv) > 1 else "linux"
    sys.exit(run(target))
