"""Bridge to the Rust 'popcore' engine (process table + registry).

Protocol: one tab-separated request line in, response lines + a line "." out.
If the Rust binary is not built, PyCore implements the identical protocol so
POP still works (slower and without Rust's memory-safety guarantees).
"""
import os
import random
import subprocess

TOTAL_KB = 8 * 1024 * 1024
BASE_USED_KB = 1_100_000


class PyCore:
    backend = "python (fallback)"

    def __init__(self):
        self.procs, self.step, self.next, self.nprot = [], 1, 1, 0
        self.reg, self.rng = {}, random.Random(7)

    def _ensure(self, key):
        parts = key.split("\\")
        for i in range(1, len(parts) + 1):
            k = "\\".join(parts[:i])
            self.reg.setdefault(k.upper(), [k, {}])

    def request(self, *f):
        f = [str(x) for x in f] + [""] * 5
        c = f[0]
        if c == "INIT":
            self.step, self.next, self.nprot = int(f[1]), int(f[2]), int(f[3])
            self.procs = []
            return "ok"
        if c == "SPAWN":
            pid = self.next
            self.next += self.step
            self.procs.append({"pid": pid, "ppid": int(f[1]), "state": "S", "mem": int(f[2]),
                               "name": f[3], "prot": len(self.procs) < self.nprot})
            return str(pid)
        if c == "KILL":
            for p in self.procs:
                if str(p["pid"]) == f[1]:
                    if p["prot"]:
                        return "err\tprotected"
                    self.procs.remove(p)
                    return "ok"
            return "err\tnotfound"
        if c == "PS":
            for p in self.procs:                       # tiny scheduler simulation
                r = self.rng.randrange(1000)
                if r % 5 == 0:
                    p["state"] = "R" if p["state"] == "S" else "S"
                p["mem"] = max(256, p["mem"] + (r % 64 if r % 2 == 0 else -(r % 64)))
            return "\n".join(f"{p['pid']}\t{p['ppid']}\t{p['state']}\t{p['mem']}\t{p['name']}" for p in self.procs)
        if c == "MEM":
            used = BASE_USED_KB + sum(p["mem"] for p in self.procs)
            return f"{TOTAL_KB}\t{used}\t{max(0, TOTAL_KB - used)}"
        if c == "REGADD":
            self._ensure(f[1])
            if f[2]:
                self.reg[f[1].upper()][1][f[2].upper()] = (f[2], f[3], f[4])
            return "ok"
        if c == "REGDEL":
            ku = f[1].upper()
            if f[2]:
                if ku in self.reg and self.reg[ku][1].pop(f[2].upper(), None):
                    return "ok"
                return "err"
            victims = [k for k in self.reg if k == ku or k.startswith(ku + "\\")]
            for k in victims:
                del self.reg[k]
            return "ok" if victims else "err"
        if c == "REGQ":
            ku = f[1].upper()
            if ku not in self.reg:
                return "err"
            out = [f"V\t{n}\t{t}\t{d}" for n, t, d in self.reg[ku][1].values()]
            pre = ku + "\\"
            out += [f"K\t{v[0]}" for k, v in sorted(self.reg.items())
                    if k.startswith(pre) and "\\" not in k[len(pre):]]
            return "\n".join(out)
        if c == "REGSAVE":
            with open(f[1], "w", encoding="utf-8") as fh:
                for k, (disp, vals) in sorted(self.reg.items()):
                    if not vals:
                        fh.write(f"{disp}\t\t\t\n")
                    for n, t, d in vals.values():
                        fh.write(f"{disp}\t{n}\t{t}\t{d}\n")
            return "ok"
        if c == "REGLOAD":
            if not os.path.exists(f[1]):
                return "err"
            self.reg = {}
            with open(f[1], encoding="utf-8") as fh:
                for line in fh:
                    p = (line.rstrip("\n").split("\t") + ["", "", "", ""])[:4]
                    self.request("REGADD", *p)
            return "ok"
        return "err\tunknown"


class RustCore:
    backend = "rust (popcore)"

    def __init__(self, exe):
        self.p = subprocess.Popen([exe, "serve"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  text=True, bufsize=1)

    def request(self, *f):
        self.p.stdin.write("\t".join(str(x).replace("\n", " ") for x in f) + "\n")
        self.p.stdin.flush()
        out = []
        while True:
            line = self.p.stdout.readline()
            if line == "":
                raise RuntimeError("popcore terminated")
            line = line.rstrip("\n")
            if line == ".":
                return "\n".join(out)
            out.append(line)

    def close(self):
        try:
            self.p.stdin.close()
            self.p.wait(timeout=2)
        except Exception:
            self.p.kill()


def make_core(home):
    exe = os.path.join(home, "bin", "popcore")
    if os.path.isfile(exe) and os.access(exe, os.X_OK):
        try:
            c = RustCore(exe)
            c.request("INIT", 1, 1, 0)
            return c
        except Exception:
            pass
    return PyCore()
