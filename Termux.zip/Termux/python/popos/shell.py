"""POP shell core.

Tokenizer, pipelines (|), redirection (> >>), sequencing (; &&), globbing,
tab-completion, history and script execution.  Every OS environment subclasses
Shell, so the interaction model is identical on Linux, Windows and macOS.
Commands are methods named c_<name> (underscores become '-').
"""
import fnmatch
import os
import posixpath
import re
import shutil
import sys
import time

try:
    import readline
except ImportError:           # pragma: no cover
    readline = None

from .vfs import FSError

ANSI = {"reset": "\033[0m", "bold": "\033[1m", "dim": "\033[2m", "red": "\033[31m",
        "green": "\033[32m", "yellow": "\033[33m", "blue": "\033[34m",
        "mag": "\033[35m", "cyan": "\033[36m"}


def col(s, c):
    return f"{ANSI[c]}{s}{ANSI['reset']}"


def nap(t):
    """Sleep unless POP_FAST is set (used by tests)."""
    if not os.environ.get("POP_FAST"):
        time.sleep(t)


def progress_bar(label, width=30, delay=0.03):
    for i in range(width + 1):
        sys.stdout.write(f"\r{label} [{'#' * i}{'.' * (width - i)}] {i * 100 // width:3d}%")
        sys.stdout.flush()
        nap(delay)
    print()


def parse_flags(args):
    """Split ['-la', 'x', '--all'] into ({'l','a','all'}, ['x'])."""
    flags, rest = set(), []
    for i, a in enumerate(args):
        if a == "--":
            rest += args[i + 1:]
            break
        if a.startswith("--") and len(a) > 2:
            flags.add(a[2:])
        elif a.startswith("-") and len(a) > 1 and not a[1:].isdigit():
            flags.update(a[1:])
        else:
            rest.append(a)
    return flags, rest


class CmdError(Exception):
    """Command failure; message is printed to stderr (empty = silent)."""


class ExitShell(Exception):
    pass


FS_PREFIX = {"mkdir": "cannot create directory '{p}'", "ls": "cannot access '{p}'",
             "rm": "cannot remove '{p}'", "touch": "cannot touch '{p}'",
             "cp": "cannot stat '{p}'", "mv": "cannot stat '{p}'", "stat": "cannot stat '{p}'",
             "head": "cannot open '{p}' for reading", "tail": "cannot open '{p}' for reading"}


class Shell:
    os_name = "generic"
    case_insensitive = False
    win = False
    pathsep = ":"

    def __init__(self, vfs, core, home):
        self.vfs, self.core, self.home = vfs, core, home
        self.user, self.host, self.cwd = "user", "pop", home
        self.env, self.aliases, self.history = {}, {}, []
        self.status, self.reboot, self.color = 0, False, False
        self.t0, self.pid, self.state_path = time.time(), 0, None
        self._orig = {}
        self.cmds = {}
        for n in dir(self):
            if n.startswith("c_"):
                self.cmds[self.norm(n[2:].replace("_", "-"))] = getattr(self, n)
                if not self.win:                          # sw_vers, system_profiler ... keep underscores
                    self.cmds.setdefault(n[2:], getattr(self, n))

    # ------------------------------------------------------------ hooks
    def norm(self, name):
        return name.lower() if self.case_insensitive else name

    def _inpath(self, p):
        return self.vfs.normalize(p, self.cwd)

    def inpath(self, p):
        r = self._inpath(p)
        self._orig[r] = p
        return r

    def outpath(self, p):
        return p

    def expand(self, t):
        return t

    def notfound(self, name):
        return f"{name}: command not found"

    def fserr(self, cmd, e):
        shown = self._orig.get(e.path, e.path)
        return f"{cmd}: {FS_PREFIX.get(cmd, '{p}').format(p=shown)}: {e.msg}"

    def prompt(self):
        return "$ "

    def boot(self, first):
        pass

    # ----------------------------------------------------- tiny helpers
    def err(self, msg):
        sys.stdout.flush()
        print(msg, file=sys.stderr)

    def read(self, p):
        return self.vfs.read(self.inpath(p))

    def spawn(self, name, ppid, mem):
        return int(self.core.request("SPAWN", ppid, mem, name))

    def procs(self):
        return [l.split("\t") for l in self.core.request("PS").splitlines() if l]

    def capture(self, line):
        """Run a command line and return its stdout (used for $(...))."""
        import io
        old, buf = sys.stdout, io.StringIO()
        sys.stdout = buf
        try:
            self.run_line(line)
        finally:
            sys.stdout = old
        return buf.getvalue().rstrip("\n")

    def uptime_s(self):
        return int(time.time() - self.t0) + 42

    def columns(self, names):
        width = shutil.get_terminal_size((80, 24)).columns
        cw = max((len(n) for n in names), default=0) + 2
        per = max(1, width // cw)
        rows = -(-len(names) // per)
        lines = []
        for r in range(rows):
            lines.append("".join(names[r + c * rows].ljust(cw) for c in range(per) if r + c * rows < len(names)).rstrip())
        return "\n".join(lines)

    # ------------------------------------------------------- tokenizer
    def tokenize(self, line):
        toks, cur, has, q, i, n = [], "", False, None, 0, len(line)
        esc = not self.win
        while i < n:
            ch = line[i]
            if q:
                if ch == q:
                    q = None
                elif ch == "\\" and q == '"' and esc and i + 1 < n and line[i + 1] in '"\\$':
                    i += 1
                    cur += line[i]
                else:
                    cur += ch
            elif ch in "\"'":
                q, has = ch, True
            elif ch == "\\" and esc and i + 1 < n:
                i += 1
                cur += line[i]
                has = True
            elif ch in " \t":
                if has:
                    toks.append((cur, False))
                    cur, has = "", False
            elif ch in "|>&;":
                if has:
                    toks.append((cur, False))
                    cur, has = "", False
                op = ch
                if i + 1 < n and line[i + 1] == ch and ch in "|>&":
                    op, i = ch * 2, i + 1
                toks.append((op, True))
            else:
                cur += ch
                has = True
            i += 1
        if q:
            raise CmdError("syntax error: unterminated quoted string")
        if has:
            toks.append((cur, False))
        return toks

    # -------------------------------------------------------- globbing
    def glob(self, pat):
        p = pat.replace("\\", "/") if self.win else pat
        d, sl, b = p.rpartition("/")
        try:
            node = self.vfs.get(self.inpath(d if d else ("/" if sl else ".")))
        except FSError:
            return []
        if node.kind != "d":
            return []
        out = []
        for name in sorted(node.children, key=str.lower):
            if name.startswith(".") and not b.startswith("."):
                continue
            ok = fnmatch.fnmatchcase(name.lower(), b.lower()) if self.case_insensitive else fnmatch.fnmatchcase(name, b)
            if ok:
                out.append(pat[:len(pat) - len(b)] + name)
        return out

    def globs(self, argv):
        out = [argv[0]]
        for j, a in enumerate(argv[1:], 1):
            if ("*" in a or "?" in a) and not a.startswith("-") and \
                    argv[j - 1].lower() not in ("-name", "-iname", "-filter", "-pattern", "-include"):
                m = self.glob(a)
                if m:
                    out += m
                    continue
            out.append(a)
        return out

    # -------------------------------------------------------- execution
    def run_line(self, line):
        line = line.strip()
        if self.win and line.startswith("@"):
            line = line[1:].strip()
        if not line or line.startswith("#") or (self.win and line.startswith("::")):
            return
        try:
            toks = self.tokenize(line)
        except CmdError as e:
            self.err(str(e))
            self.status = 2
            return
        groups, cur = [], []
        for t, op in toks:
            if op and t in (";", "&", "&&"):
                groups.append((cur, t))
                cur = []
            else:
                cur.append((t, op))
        groups.append((cur, ";"))
        prev = ";"
        for grp, sep in groups:
            if prev == "&&" and self.status != 0:
                prev = sep
                continue
            if grp:
                self.run_pipeline(grp)
            prev = sep

    def run_pipeline(self, grp):
        stages = [[]]
        for t, op in grp:
            if op and t == "|":
                stages.append([])
            else:
                stages[-1].append((t, op))
        redir, last = None, stages[-1]
        for k, (t, op) in enumerate(last):
            if op and t in (">", ">>"):
                if k + 1 >= len(last):
                    self.err("syntax error near unexpected token `newline'")
                    self.status = 2
                    return
                redir = (t, last[k + 1][0])
                stages[-1] = last[:k] + last[k + 2:]
                break
        data = None
        try:
            for si, st in enumerate(stages):
                argv = [self.expand(t) for t, op in st if not op]
                if not argv:
                    raise CmdError("syntax error near unexpected token `|'")
                argv = self.globs(argv)
                self.color = si == len(stages) - 1 and redir is None and sys.stdout.isatty()
                data = self.dispatch(argv, data)
            self.status = 0
        except CmdError as e:
            if str(e):
                self.err(str(e))
            self.status = 1
            return
        except FSError as e:
            self.err(f"{e.path}: {e.msg}")
            self.status = 1
            return
        except (ExitShell, KeyboardInterrupt):
            raise
        except Exception as e:                      # never crash the session
            self.err(f"pop: internal error: {type(e).__name__}: {e}")
            self.status = 1
            return
        if redir:
            try:
                ap = self.inpath(redir[1])
                if ap != "/dev/null":
                    txt = data or ""
                    if txt and not txt.endswith("\n"):
                        txt += "\n"
                    self.vfs.write(ap, txt, append=redir[0] == ">>", owner=self.user)
            except FSError as e:
                self.err(self.fserr("redirect", e))
                self.status = 1
        elif data:
            sys.stdout.write(data if data.endswith("\n") else data + "\n")
            sys.stdout.flush()

    def dispatch(self, argv, stdin):
        name = argv[0]
        key = self.norm(name)
        if key in self.aliases:
            argv = self.aliases[key].split() + argv[1:]
            name, key = argv[0], self.norm(argv[0])
        fn = self.cmds.get(key)
        try:
            if fn:
                return fn(argv[1:], stdin)
            return self.run_external(name, argv[1:], stdin)
        except FSError as e:
            raise CmdError(self.fserr(name, e))

    def find_exe(self, name):
        bare = os.path.basename(name.replace("\\", "/"))
        cands = [name]
        if self.win and "." not in bare:
            cands = [name + e for e in (".exe", ".bat", ".cmd", ".ps1")]
        has_dir = "/" in name or (self.win and "\\" in name)
        for c in cands:
            if has_dir:
                paths = [self.inpath(c)]
            else:
                paths = [self.vfs.normalize(c, self.cwd)] if self.win else []
                paths += [self.inpath(d).rstrip("/") + "/" + c for d in self.env.get("PATH", "").split(self.pathsep) if d]
            for p in paths:
                try:
                    n = self.vfs.get(p)
                except FSError:
                    continue
                if n.kind == "f":
                    return p, n
        return None

    def run_external(self, name, args, stdin):
        hit = self.find_exe(name)
        if not hit:
            raise CmdError(self.notfound(name))
        p, n = hit
        if not self.win and not n.mode & 0o111:
            raise CmdError(f"{self.shell_name}: {name}: Permission denied")
        if n.data.startswith("POPBIN"):
            return f"{posixpath.basename(p)}: simulated binary - POP does not execute native code."
        self.run_script(n.data, args)
        return ""

    def run_script(self, text, args=()):
        for k, v in enumerate(args, 1):
            self.env[str(k)] = v
        for line in text.splitlines():
            if not line.startswith("#!"):
                self.run_line(line)

    # -------------------------------------------------- interactive loop
    def loop(self):
        self.setup_readline()
        while True:
            try:
                line = input(re.sub(r"(\033\[[0-9;]*m)", "\001\\1\002", self.prompt()))
            except EOFError:
                print()
                break
            except KeyboardInterrupt:
                print("^C")
                continue
            if line.strip():
                self.history.append(line)
            try:
                self.run_line(line)
            except ExitShell:
                break
            except KeyboardInterrupt:
                print("^C")

    def setup_readline(self):
        if not readline:
            return
        readline.set_completer_delims(" \t\n;|>&")

        def comp(text, state):
            before = readline.get_line_buffer()[:readline.get_begidx()].rstrip()
            if before == "" or before.endswith((";", "|", "&&")):
                opts = [c for c in sorted(self.cmds) if c.startswith(self.norm(text))]
            else:
                opts = self.complete_path(text)
            return opts[state] if state < len(opts) else None
        readline.set_completer(comp)
        readline.parse_and_bind("tab: complete")

    def complete_path(self, text):
        sepset = "/\\" if self.win else "/"
        cut = max((text.rfind(s) for s in sepset), default=-1) + 1
        d, base = text[:cut], text[cut:]
        try:
            node = self.vfs.get(self.inpath(d or "."))
        except FSError:
            return []
        out = []
        for n, c in sorted(node.children.items()) if node.kind == "d" else []:
            if self.norm(n).startswith(self.norm(base)):
                out.append(d + n + (("\\" if self.win else "/") if c.kind == "d" else ""))
        return out

    # ---------------------------------------------------- common commands
    def c_exit(self, a, i):
        raise ExitShell()

    c_logout = c_poweroff = c_halt = c_exit

    def c_reboot(self, a, i):
        self.reboot = True
        raise ExitShell()

    def c_clear(self, a, i):
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()

    def c_pop_info(self, a, i):
        files = sum(1 for _ in self.vfs.walk("/"))
        return (f"POP {self.os_name} environment\n  process/registry engine : {self.core.backend}\n"
                f"  virtual nodes           : {files}\n  state file              : {self.state_path}\n"
                f"  commands available      : {len(self.cmds)}")

    def c_pop_reset(self, a, i):
        ans = input("Delete the saved state of this OS (it is regenerated on next boot)? [y/N] ")
        if ans.strip().lower() == "y":
            for p in (self.state_path, getattr(self, "reg_path", None)):
                if p and os.path.exists(p):
                    os.remove(p)
            print("State removed. Shutting down...")
            raise ExitShell()
        return "Cancelled."

    def c_help(self, a, i):
        names = sorted(k for k in self.cmds if not (self.win and not self.ps and "-" in k))
        return (f"{self.os_name} commands ({len(names)}) - TAB completes, Up/Down = history, "
                f"'exit' returns to the POP menu:\n\n" + self.columns(names))
