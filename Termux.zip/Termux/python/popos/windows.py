"""POP Windows: NT-style C:\\ layout, cmd.exe + PowerShell, registry (Rust core)."""
import fnmatch
import os
import posixpath
import re
import time

from .shell import Shell, CmdError, ExitShell, col, nap, progress_bar
from .vfs import FSError

BIN = "POPBIN"
VER = "10.0.22631.4460"
HIVES = {"HKLM": "HKEY_LOCAL_MACHINE", "HKCU": "HKEY_CURRENT_USER", "HKCR": "HKEY_CLASSES_ROOT",
         "HKU": "HKEY_USERS", "HKCC": "HKEY_CURRENT_CONFIG"}
PS_ALIAS = {"ls": "Get-ChildItem", "dir": "Get-ChildItem", "gci": "Get-ChildItem", "cd": "Set-Location",
            "sl": "Set-Location", "chdir": "Set-Location", "pwd": "Get-Location", "gl": "Get-Location",
            "cat": "Get-Content", "type": "Get-Content", "gc": "Get-Content", "rm": "Remove-Item",
            "del": "Remove-Item", "erase": "Remove-Item", "ri": "Remove-Item", "cp": "Copy-Item",
            "copy": "Copy-Item", "mv": "Move-Item", "move": "Move-Item", "mi": "Move-Item",
            "echo": "Write-Output", "write": "Write-Output", "ps": "Get-Process", "gps": "Get-Process",
            "kill": "Stop-Process", "cls": "Clear-Host", "clear": "Clear-Host", "sls": "Select-String",
            "man": "Get-Help", "help": "Get-Help", "gcm": "Get-Command", "md": "New-Item -ItemType Directory -Path",
            "mkdir": "New-Item -ItemType Directory -Path", "ni": "New-Item", "ni": "New-Item",
            "sc": "Set-Content", "ac": "Add-Content", "gsv": "Get-Service", "date": "Get-Date"}
SERVICES = [("AudioEndpointBuilder", "Windows Audio Endpoint Builder", "Running"), ("BITS", "Background Intelligent Transfer Service", "Stopped"),
            ("Dhcp", "DHCP Client", "Running"), ("Dnscache", "DNS Client", "Running"), ("EventLog", "Windows Event Log", "Running"),
            ("mpssvc", "Windows Defender Firewall", "Running"), ("Spooler", "Print Spooler", "Running"),
            ("WinDefend", "Microsoft Defender Antivirus Service", "Running"), ("wuauserv", "Windows Update", "Stopped")]
WINGET = {"Git.Git": "2.47.1", "Python.Python.3.12": "3.12.8", "Microsoft.VisualStudioCode": "1.95.3",
          "7zip.7zip": "24.09", "Notepad++.Notepad++": "8.7.4", "VideoLAN.VLC": "3.0.21"}
HOSTS = "# Copyright (c) 1993-2009 Microsoft Corp.\r\n#\r\n# This is a sample HOSTS file used by Microsoft TCP/IP for Windows.\r\n127.0.0.1       localhost\r\n::1             localhost\r\n"


def psargs(args, valued):
    named, pos, j = {}, [], 0
    while j < len(args):
        a = args[j]
        if a.startswith("-") and len(a) > 1 and not a[1:].replace(".", "").isdigit():
            k = a[1:].lower()
            if k in valued and j + 1 < len(args):
                named[k] = args[j + 1]
                j += 2
                continue
            named[k] = True
        else:
            pos.append(a)
        j += 1
    return named, pos


def dstr(t):
    return time.strftime("%m/%d/%Y  %I:%M %p", time.localtime(t))


class WindowsShell(Shell):
    os_name = "windows"
    case_insensitive = True
    win = True
    pathsep = ";"
    home_dir = "/Users/user"
    ps = False
    ps_depth = 0

    # ----------------------------------------------------------- FS tree
    @classmethod
    def generate(cls, vfs):
        yield "Laying out the C:\\ volume (Windows, Program Files, Users)"
        tree = {
            "Windows": {"System32": {"drivers": {"etc": {"hosts": HOSTS, "services": "# services\r\n"}}, "config": {"SAM": BIN, "SYSTEM": BIN, "SOFTWARE": BIN},
                                      "en-US": {}, "winevt": {"Logs": {}}, "Wbem": {}, "WindowsPowerShell": {"v1.0": {"powershell.exe": BIN + " powershell"}}},
                        "SysWOW64": {}, "Fonts": {"arial.ttf": BIN, "segoeui.ttf": BIN}, "Temp": {}, "Logs": {}, "Boot": {}, "Resources": {},
                        "explorer.exe": BIN + " explorer", "notepad.exe": BIN + " notepad", "regedit.exe": BIN + " regedit",
                        "win.ini": "; for 16-bit app support\r\n[fonts]\r\n[extensions]\r\n", "WindowsUpdate.log": ""},
            "Program Files": {"Windows Defender": {"MsMpEng.exe": BIN}, "Common Files": {}, "Internet Explorer": {"iexplore.exe": BIN},
                              "Windows NT": {"Accessories": {"wordpad.exe": BIN}}, "WindowsApps": {}},
            "Program Files (x86)": {"Common Files": {}, "Microsoft": {}},
            "ProgramData": {"Microsoft": {"Windows": {"Start Menu": {}}}},
            "Users": {"Public": {"Documents": {}, "Downloads": {}, "Desktop": {}}, "Default": {},
                      "user": {d: {} for d in "Desktop Documents Downloads Pictures Music Videos Favorites Links".split()}},
            "pagefile.sys": BIN, "bootmgr": BIN, "DumpStack.log.tmp": "",
        }
        for n in ("cmd", "ipconfig", "ping", "tasklist", "taskkill", "systeminfo", "reg", "net", "sfc", "chkdsk", "where", "hostname", "whoami", "tree", "find", "findstr", "attrib", "winget", "more", "shutdown"):
            tree["Windows"]["System32"][n + ".exe"] = BIN + " " + n
        vfs.populate("/", tree, owner="SYSTEM")
        yield "Creating the user profile (C:\\Users\\user)"
        vfs.populate("/Users/user", {"AppData": {"Local": {"Temp": {}, "Microsoft": {}}, "Roaming": {"Microsoft": {}}, "LocalLow": {}},
                                     "NTUSER.DAT": BIN, "Documents": {"notes.txt": "POP Windows notes\r\nType HELP to list commands.\r\n"},
                                     "Desktop": {"welcome.bat": "@echo off\r\necho Welcome to POP Windows, %USERNAME%!\r\necho Today is running on %COMPUTERNAME%\r\n"}}, owner="user")
        yield "Writing system files and hidden attributes"
        vfs.write("/Windows/System32/drivers/etc/hosts", HOSTS)
        yield "Registering file associations"
        yield "Windows is ready"

    # ------------------------------------------------------------- hooks
    def _inpath(self, p):
        p = p.replace("\\", "/")
        m = re.match(r"^([A-Za-z]):(.*)$", p)
        if m:
            if m.group(1).upper() != "C":
                raise FSError("The system cannot find the drive specified.", p)
            p = m.group(2) or self.cwd
        return self.vfs.normalize(p, self.cwd)

    def outpath(self, p):
        return "C:" + p.replace("/", "\\") if p != "/" else "C:\\"

    def expand(self, t):
        low = {k.lower(): v for k, v in self.env.items()}
        if self.ps:
            t = re.sub(r"\$env:(\w+)", lambda m: low.get(m.group(1).lower(), ""), t, flags=re.I)
            t = t.replace("$PWD", self.outpath(self.cwd)).replace("$HOME", low["userprofile"])
        return re.sub(r"%(\w+)%", lambda m: low.get(m.group(1).lower(), m.group(0)), t)

    def fserr(self, cmd, e):
        shown = self._orig.get(e.path, e.path)
        shown = shown if "/" not in shown or "\\" in shown else shown
        if self.ps:
            return f"{cmd} : Cannot find path '{self.outpath(e.path)}' because it does not exist."
        if cmd.lower() in ("cd", "chdir"):
            return "The system cannot find the path specified."
        if cmd.lower() == "dir":
            return "File Not Found"
        if e.msg == "File exists":
            return f"A subdirectory or file {shown} already exists."
        if e.msg == "Is a directory":
            return "Access is denied."
        return {"No such file or directory": "The system cannot find the file specified.",
                "Not a directory": "The system cannot find the path specified.",
                "Directory not empty": "The directory is not empty."}.get(e.msg, e.msg)

    def notfound(self, n):
        if not self.ps:
            return f"'{n}' is not recognized as an internal or external command,\noperable program or batch file."
        return (f"{n} : The term '{n}' is not recognized as the name of a cmdlet, function, script file, or operable program. "
                f"Check the spelling of the name, or if a path was included, verify that the path is correct and try again.\n"
                f"At line:1 char:1\n+ {n}\n+ {'~' * len(n)}\n    + CategoryInfo          : ObjectNotFound: ({n}:String) [], CommandNotFoundException\n"
                f"    + FullyQualifiedErrorId : CommandNotFoundException")

    def prompt(self):
        return f"PS {self.outpath(self.cwd)}> " if self.ps else f"{self.outpath(self.cwd)}>"

    def dispatch(self, argv, stdin):
        k = argv[0].lower()
        if self.ps and k in PS_ALIAS:
            argv = PS_ALIAS[k].split() + argv[1:]
        elif not self.ps and "-" in k and k in self.cmds:       # cmdlets only exist in PowerShell
            raise CmdError(self.notfound(argv[0]))
        return super().dispatch(argv, stdin)

    def boot(self, first):
        reg_ok = self.core.request("REGLOAD", self.reg_path) == "ok" if os.path.exists(self.reg_path) else False
        self.core.request("INIT", 4, 0, 3)
        for name, ppid, mem in [("System Idle Process", 0, 8), ("System", 0, 144), ("Registry", 4, 52000)]:
            self.spawn(name, ppid, mem)
        for name, mem in [("smss.exe", 1100), ("csrss.exe", 5200), ("wininit.exe", 6800), ("services.exe", 9000), ("lsass.exe", 15200),
                          ("svchost.exe", 18000), ("svchost.exe", 12400), ("winlogon.exe", 9800), ("dwm.exe", 45000), ("explorer.exe", 98000)]:
            self.spawn(name, 4, mem)
        self.pid = self.spawn("cmd.exe", 0, 4800)
        low = {"USERNAME": "user", "USERPROFILE": "C:\\Users\\user", "COMPUTERNAME": "POP-PC", "SystemRoot": "C:\\Windows", "windir": "C:\\Windows",
               "SystemDrive": "C:", "OS": "Windows_NT", "HOMEDRIVE": "C:", "HOMEPATH": "\\Users\\user", "ProgramFiles": "C:\\Program Files",
               "ProgramData": "C:\\ProgramData", "TEMP": "C:\\Users\\user\\AppData\\Local\\Temp", "TMP": "C:\\Users\\user\\AppData\\Local\\Temp",
               "APPDATA": "C:\\Users\\user\\AppData\\Roaming", "LOCALAPPDATA": "C:\\Users\\user\\AppData\\Local", "PROCESSOR_ARCHITECTURE": "ARM64",
               "PATHEXT": ".COM;.EXE;.BAT;.CMD;.PS1", "PATH": "C:\\Windows\\system32;C:\\Windows;C:\\Windows\\System32\\Wbem;C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\",
               "ComSpec": "C:\\Windows\\system32\\cmd.exe", "PROMPT": "$P$G"}
        self.env.update(low)
        if not reg_ok:
            self.seed_registry()
        print(col("POP Boot Manager", "bold") + "  -  Windows Boot Manager (UEFI)")
        for m in ("Loading boot files", "Starting Windows", "Initializing kernel (ntoskrnl.exe)", "Starting session manager (smss.exe)",
                  "Starting services (services.exe, lsass.exe)", "Loading user profile", "Starting explorer.exe"):
            progress_bar(f"  {m:<44}", 14, 0.025)
        print(f"\nMicrosoft Windows [Version {VER}]\n(c) Microsoft Corporation. All rights reserved.\n")

    def seed_registry(self):
        L, U = HIVES["HKLM"], HIVES["HKCU"]
        cv = f"{L}\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion"
        vals = [(cv, "ProductName", "REG_SZ", "Windows 11 Pro"), (cv, "DisplayVersion", "REG_SZ", "23H2"), (cv, "CurrentBuild", "REG_SZ", "22631"),
                (cv, "CurrentBuildNumber", "REG_SZ", "22631"), (cv, "CurrentVersion", "REG_SZ", "6.3"), (cv, "RegisteredOwner", "REG_SZ", "user"),
                (cv, "SystemRoot", "REG_SZ", "C:\\Windows"), (cv, "UBR", "REG_DWORD", "0x116c"),
                (f"{L}\\SYSTEM\\CurrentControlSet\\Control\\ComputerName\\ComputerName", "ComputerName", "REG_SZ", "POP-PC"),
                (f"{L}\\HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", "ProcessorNameString", "REG_SZ", "POP Virtual CPU @ 2.40GHz"),
                (f"{L}\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", "SecurityHealth", "REG_EXPAND_SZ", "%windir%\\system32\\SecurityHealthSystray.exe"),
                (f"{U}\\Environment", "TEMP", "REG_EXPAND_SZ", "%USERPROFILE%\\AppData\\Local\\Temp"),
                (f"{U}\\Control Panel\\Desktop", "Wallpaper", "REG_SZ", "C:\\Windows\\Web\\Wallpaper\\Windows\\img0.jpg"),
                (f"{U}\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Hidden", "REG_DWORD", "0x2")]
        for k, n, t, d in vals:
            self.core.request("REGADD", k, n, t, d)

    # ------------------------------------------------- registry helpers
    def longkey(self, k):
        k = k.replace("/", "\\").replace(":", "").strip("\\")
        head, _, rest = k.partition("\\")
        return HIVES.get(head.upper(), head) + ("\\" + rest if rest else "")

    def reg_dump(self, key, recurse, out):
        res = self.core.request("REGQ", key)
        if res == "err":
            raise CmdError("ERROR: The system was unable to find the specified registry key or value.")
        vals = [l.split("\t") for l in res.splitlines() if l.startswith("V")]
        subs = [l.split("\t")[1] for l in res.splitlines() if l.startswith("K")]
        out.append("\n" + key)
        for _, n, t, d in vals:
            out.append(f"    {n}    {t}    {d}")
        if recurse:
            for s in subs:
                self.reg_dump(s, True, out)
        else:
            out += [f"\n{s}" for s in subs]

    def c_reg(self, a, i):
        if not a:
            raise CmdError("REG Operation [Parameters]\n  REG QUERY | ADD | DELETE | EXPORT")
        op, rest = a[0].lower(), a[1:]
        if not rest:
            raise CmdError("ERROR: Invalid syntax.")
        key = self.longkey(rest[0])
        opt = {}
        for j, x in enumerate(rest[1:], 1):
            if x.lower() in ("/v", "/t", "/d") and j + 1 < len(rest):
                opt[x.lower()] = rest[j + 1]
        flags = [x.lower() for x in rest[1:]]
        if op == "query":
            out = []
            if "/v" in opt:
                res = self.core.request("REGQ", key)
                hit = [l.split("\t") for l in res.splitlines() if l.startswith("V") and l.split("\t")[1].lower() == opt["/v"].lower()]
                if not hit:
                    raise CmdError("ERROR: The system was unable to find the specified registry key or value.")
                return f"\n{key}\n" + "\n".join(f"    {n}    {t}    {d}" for _, n, t, d in hit) + "\n"
            self.reg_dump(key, "/s" in flags, out)
            return "\n".join(out) + "\n"
        if op == "add":
            if key.count("\\") < 1:
                raise CmdError("ERROR: Invalid key name.")
            self.core.request("REGADD", key, opt.get("/v", ""), opt.get("/t", "REG_SZ").upper(), opt.get("/d", ""))
            return "The operation completed successfully."
        if op == "delete":
            if self.core.request("REGDEL", key, opt.get("/v", "")).startswith("err"):
                raise CmdError("ERROR: The system was unable to find the specified registry key or value.")
            return "The operation completed successfully."
        raise CmdError("ERROR: Invalid syntax.")

    # ----------------------------------------------------- cmd.exe basics
    def _opts(self, a):
        return [x.lower() for x in a if x.startswith("/")], [x for x in a if not x.startswith("/")]

    def c_dir(self, a, i):
        fl, args = self._opts(a)
        ap = self.inpath(args[0] if args else ".")
        node = self.vfs.get(ap)
        if node.kind == "f":
            items, d = [(posixpath.basename(ap), node)], posixpath.dirname(ap) or "/"
        else:
            items = ([(".", node), ("..", node)] if ap != "/" else []) + sorted(node.children.items(), key=lambda kv: kv[0].lower())
            d = ap
        if "/b" in fl:
            return "\n".join(n for n, _ in items if n not in (".", ".."))
        out = [" Volume in drive C has no label.", " Volume Serial Number is 4A2F-9C1D", "", f" Directory of {self.outpath(self.vfs.canon(d))}", ""]
        nf = nd = tot = 0
        for n, c in items:
            if c.kind == "d":
                nd += 1
                out.append(f"{dstr(c.mtime)}    <DIR>          {n}")
            else:
                nf += 1
                tot += c.size()
                out.append(f"{dstr(c.mtime)} {c.size():>18,} {n}")
        out += [f"{nf:>16} File(s){tot:>15,} bytes", f"{nd:>16} Dir(s){118263545856:>16,} bytes free"]
        return "\n".join(out)

    def c_cd(self, a, i):
        _, args = self._opts(a)
        if not args:
            return self.outpath(self.cwd)
        p = self.inpath(" ".join(args))
        if self.vfs.get(p).kind != "d":
            raise CmdError("The directory name is invalid.")
        self.cwd = self.vfs.canon(p)

    c_chdir = c_cd

    def c_cls(self, a, i):
        return self.c_clear(a, i)

    def c_type(self, a, i):
        return "".join(self.read(f) for f in a)

    def c_echo(self, a, i):
        t = " ".join(a)
        if not a:
            return "ECHO is on."
        return "" if t.lower() in ("on", "off") else t + "\n"

    def c_md(self, a, i):
        for d in a:
            self.vfs.mkdir(self.inpath(d), parents=True, owner=self.user)

    c_mkdir = c_md

    def c_rd(self, a, i):
        fl, args = self._opts(a)
        for d in args:
            n = self.vfs.get(self.inpath(d))
            if n.children and "/s" not in fl:
                raise CmdError("The directory is not empty.")
            self.vfs.remove(self.inpath(d), True)

    c_rmdir = c_rd

    def c_del(self, a, i):
        _, args = self._opts(a)
        if not args:
            raise CmdError("The syntax of the command is incorrect.")
        for f in args:
            n = self.vfs.get(self.inpath(f))
            if n.kind == "d":
                for nm in list(n.children):
                    if n.children[nm].kind == "f":
                        del n.children[nm]
            else:
                self.vfs.remove(self.inpath(f))

    c_erase = c_del

    def c_copy(self, a, i):
        _, args = self._opts(a)
        if len(args) < 2:
            raise CmdError("The syntax of the command is incorrect.")
        dst = self.inpath(args[-1])
        isdir = self.vfs.exists(dst) and self.vfs.get(dst).kind == "d"
        for s in args[:-1]:
            sp = self.inpath(s)
            self.vfs.copy(sp, dst.rstrip("/") + "/" + posixpath.basename(sp) if isdir else dst)
        return f"        {len(args) - 1} file(s) copied."

    def c_xcopy(self, a, i):
        return self.c_copy(a, i)

    def c_move(self, a, i):
        _, args = self._opts(a)
        if len(args) < 2:
            raise CmdError("The syntax of the command is incorrect.")
        dst = self.inpath(args[-1])
        isdir = self.vfs.exists(dst) and self.vfs.get(dst).kind == "d"
        sp = self.inpath(args[0])
        self.vfs.get(sp)
        self.vfs.move(sp, dst.rstrip("/") + "/" + posixpath.basename(sp) if isdir else dst)
        return "        1 file(s) moved."

    def c_ren(self, a, i):
        if len(a) != 2:
            raise CmdError("The syntax of the command is incorrect.")
        sp = self.inpath(a[0])
        self.vfs.get(sp)
        self.vfs.move(sp, posixpath.dirname(sp).rstrip("/") + "/" + a[1])

    c_rename = c_ren

    def c_set(self, a, i):
        if not a:
            return "\n".join(f"{k}={v}" for k, v in sorted(self.env.items(), key=lambda kv: kv[0].lower()) if not k.isdigit())
        k, eq, v = " ".join(a).partition("=")
        if eq:
            self.env[k] = v
        else:
            hits = [f"{n}={v}" for n, v in self.env.items() if n.lower().startswith(k.lower())]
            if not hits:
                raise CmdError(f"Environment variable {k} not defined")
            return "\n".join(hits)

    def c_ver(self, a, i):
        return f"\nMicrosoft Windows [Version {VER}]"

    def c_vol(self, a, i):
        return " Volume in drive C has no label.\n Volume Serial Number is 4A2F-9C1D"

    def c_hostname(self, a, i):
        return "POP-PC"

    def c_whoami(self, a, i):
        return "pop-pc\\user"

    def c_title(self, a, i):
        return ""

    def c_rem(self, a, i):
        return ""

    def c_pause(self, a, i):
        input("Press Enter to continue . . . ")

    def c_path(self, a, i):
        return "PATH=" + self.env["PATH"]

    def c_tree(self, a, i):
        _, args = self._opts(a)
        root, out = self.inpath(args[0] if args else "."), ["Folder PATH listing", "Volume serial number is 4A2F-9C1D", self.outpath(self.vfs.canon(root))]

        def rec(path, pre):
            n = self.vfs.get(path)
            dirs = [k for k, c in sorted(n.children.items(), key=lambda kv: kv[0].lower()) if c.kind == "d"]
            for k, nm in enumerate(dirs):
                last = k == len(dirs) - 1
                out.append(pre + ("└───" if last else "├───") + nm)
                rec(path.rstrip("/") + "/" + nm, pre + ("    " if last else "│   "))
        rec(root, "")
        return "\n".join(out)

    def c_where(self, a, i):
        hit = self.find_exe(a[0]) if a else None
        if not hit:
            raise CmdError(f"INFO: Could not find files for the given pattern(s).")
        return self.outpath(self.vfs.canon(hit[0]))

    def c_attrib(self, a, i):
        _, args = self._opts(a)
        return "\n".join(f"A            {self.outpath(self.inpath(f))}" for f in args)

    def c_find(self, a, i):
        _, args = self._opts(a)
        if not args:
            raise CmdError("FIND: Parameter format not correct")
        pat = args[0]
        src = [(f, self.read(f)) for f in args[1:]] or [("", i or "")]
        out = []
        for f, t in src:
            if f:
                out.append(f"\n---------- {f.upper()}")
            out += [l for l in t.splitlines() if pat.lower() in l.lower()]
        return "\n".join(out)

    def c_findstr(self, a, i):
        fl, args = self._opts(a)
        if not args:
            raise CmdError("FINDSTR: Bad command line")
        pat = re.compile(args[0], re.I if "/i" in fl else 0)
        src = [(f, self.read(f)) for f in args[1:]] or [("", i or "")]
        return "\n".join((f"{f}:" if f and len(src) > 1 else "") + l for f, t in src for l in t.splitlines() if pat.search(l))

    def c_more(self, a, i):
        return "".join(self.read(f) for f in a) if a else (i or "")

    def c_sort(self, a, i):
        return "\n".join(sorted((self.read(a[0]) if a else (i or "")).splitlines(), key=str.lower))

    def c_date(self, a, i):
        return time.strftime("%a %m/%d/%Y") if "/t" in [x.lower() for x in a] else f"The current date is: {time.strftime('%a %m/%d/%Y')}"

    def c_time(self, a, i):
        return time.strftime("%H:%M") if "/t" in [x.lower() for x in a] else f"The current time is: {time.strftime('%H:%M:%S')}.00"

    def c_ipconfig(self, a, i):
        return ("\nWindows IP Configuration\n\n\nWireless LAN adapter Wi-Fi:\n\n   Connection-specific DNS Suffix  . : lan\n"
                "   IPv4 Address. . . . . . . . . . . : 192.168.1.42\n   Subnet Mask . . . . . . . . . . . : 255.255.255.0\n"
                "   Default Gateway . . . . . . . . . : 192.168.1.1\n")

    def c_ping(self, a, i):
        _, args = self._opts(a)
        if not args:
            raise CmdError("IP address must be specified.")
        ip = f"93.184.{sum(map(ord, args[0])) % 200}.{sum(map(ord, args[0][::-1])) % 250 + 1}"
        print(f"\nPinging {args[0]} [{ip}] with 32 bytes of data:")
        for _ in range(4):
            nap(0.4)
            print(f"Reply from {ip}: bytes=32 time=21ms TTL=117")
        return f"\nPing statistics for {ip}:\n    Packets: Sent = 4, Received = 4, Lost = 0 (0% loss),\nApproximate round trip times in milli-seconds:\n    Minimum = 21ms, Maximum = 21ms, Average = 21ms"

    def c_tasklist(self, a, i):
        rows = ["", "Image Name                     PID Session Name        Session#    Mem Usage", "========================= ======== ================ =========== ============"]
        for p in self.procs():
            rows.append(f"{p[4]:<25} {p[0]:>8} {'Services' if int(p[0]) < 700 else 'Console':<16} {0 if int(p[0]) < 700 else 1:>11} {int(p[3]):>9,} K")
        return "\n".join(rows)

    def c_taskkill(self, a, i):
        low = [x.lower() for x in a]
        targets = []
        if "/pid" in low:
            targets = [(a[low.index("/pid") + 1], "PID")]
        elif "/im" in low:
            nm = a[low.index("/im") + 1]
            targets = [(p[0], nm) for p in self.procs() if p[4].lower() == nm.lower()]
            if not targets:
                raise CmdError(f'ERROR: The process "{nm}" not found.')
        else:
            raise CmdError("ERROR: Invalid syntax. Neither /PID nor /IM was specified.")
        out = []
        for pid, label in targets:
            r = self.core.request("KILL", pid)
            if r.startswith("err\tprotected"):
                out.append(f"ERROR: The process with PID {pid} could not be terminated.\nReason: Access is denied.")
            elif r.startswith("err"):
                raise CmdError(f'ERROR: The process "{pid}" not found.')
            else:
                out.append(f"SUCCESS: The process with PID {pid} has been terminated.")
        return "\n".join(out)

    def c_systeminfo(self, a, i):
        t, u, f = (int(x) for x in self.core.request("MEM").split("\t"))
        return (f"\nHost Name:                 POP-PC\nOS Name:                   Microsoft Windows 11 Pro\nOS Version:                {VER} Build 22631\n"
                f"OS Manufacturer:           Microsoft Corporation\nRegistered Owner:          user\nSystem Type:               ARM64-based PC\n"
                f"Processor(s):              1 Processor(s) Installed.\nWindows Directory:         C:\\Windows\nSystem Directory:          C:\\Windows\\system32\n"
                f"Total Physical Memory:     {t // 1024:,} MB\nAvailable Physical Memory: {f // 1024:,} MB\n")

    def c_net(self, a, i):
        if a and a[0].lower() == "user":
            return "\nUser accounts for \\\\POP-PC\n\n-------------------------------------------------------------------------------\nAdministrator            DefaultAccount           Guest\nuser                     WDAGUtilityAccount\nThe command completed successfully.\n"
        raise CmdError("The syntax of this command is:\n\nNET USER")

    def c_sfc(self, a, i):
        print("\nBeginning system scan.  This process will take some time.\n")
        progress_bar("Verification", 30, 0.05)
        return "\nWindows Resource Protection did not find any integrity violations."

    def c_chkdsk(self, a, i):
        return "The type of the file system is NTFS.\nWARNING!  F parameter not specified.\nRunning CHKDSK in read-only mode.\n\nStage 1: Examining basic file system structure ...\nWindows has scanned the file system and found no problems."

    def c_shutdown(self, a, i):
        low = [x.lower() for x in a]
        if "/r" in low:
            return self.c_reboot(a, i)
        if "/s" in low or "/p" in low:
            print("Windows is shutting down...")
            raise ExitShell()
        return "Usage: shutdown [/s | /r | /p]"

    def c_start(self, a, i):
        return ""

    def c_notepad(self, a, i):
        return self.c_nano(a, i)

    def c_nano(self, a, i):
        if not a:
            raise CmdError("usage: notepad FILE")
        ap = self.inpath(a[0])
        lines = self.vfs.read(ap).splitlines() if self.vfs.exists(ap) else []
        print(col(f"[ POP Notepad: {a[0]} ]  '.' = save+quit, '.q' = abort", "cyan"))
        for k, l in enumerate(lines, 1):
            print(f"{k:>3}| {l}")
        while True:
            try:
                l = input(f"{len(lines) + 1:>3}| ")
            except EOFError:
                l = "."
            if l == ".":
                self.vfs.write(ap, "\r\n".join(lines) + "\r\n" if lines else "", owner=self.user)
                return ""
            if l == ".q":
                return ""
            lines.append(l)

    def c_winget(self, a, i):
        if not a:
            return "Windows Package Manager (Preview) v1.9.25200"
        act = a[0].lower()
        inst = self.vfs.read("/Users/user/.winget-installed").splitlines() if self.vfs.exists("/Users/user/.winget-installed") else []
        if act == "search":
            q = a[1].lower() if len(a) > 1 else ""
            return "Name                 Id                          Version\n" + "-" * 55 + "\n" + "\n".join(f"{k.split('.')[-1]:<20} {k:<27} {v}" for k, v in WINGET.items() if q in k.lower())
        if act == "list":
            return "Name  Id  Version\n" + "-" * 30 + "\n" + "\n".join(f"{k.split('.')[-1]} {k} {WINGET[k]}" for k in inst if k in WINGET)
        if act == "install":
            pid = a[1] if len(a) > 1 else ""
            if pid not in WINGET:
                raise CmdError("No package found matching input criteria.")
            print(f"Found {pid.split('.')[-1]} [{pid}] Version {WINGET[pid]}\nDownloading package...")
            progress_bar("  ", 30, 0.03)
            self.vfs.write("/Users/user/.winget-installed", pid + "\n", append=True)
            os_dir = "/Program Files/" + pid.split(".")[-1]
            self.vfs.mkdir(os_dir, parents=True, owner="SYSTEM")
            return "Successfully verified installer hash\nStarting package install...\nSuccessfully installed"
        raise CmdError("The command is not supported in this simulation.")

    def c_powershell(self, a, i):
        self.ps, self.ps_depth = True, self.ps_depth + 1
        return "Windows PowerShell\nCopyright (C) Microsoft Corporation. All rights reserved.\n\nInstall the latest PowerShell for new features and improvements! https://aka.ms/PSWindows\n"

    c_pwsh = c_powershell

    def c_cmd(self, a, i):
        if self.ps:
            self.ps = False
            return f"Microsoft Windows [Version {VER}]\n(c) Microsoft Corporation. All rights reserved.\n"
        return ""

    def c_exit(self, a, i):
        if self.ps_depth > 0:
            self.ps_depth -= 1
            self.ps = self.ps_depth > 0
            return ""
        raise ExitShell()

    def c_help(self, a, i):
        if self.ps:
            return "Get-Help: use Get-Command to list cmdlets. Aliases: ls, cd, cat, rm, cp, mv, ps, kill, cls ..."
        info = {"CD": "Displays the name of or changes the current directory.", "CLS": "Clears the screen.", "COPY": "Copies one or more files to another location.",
                "DATE": "Displays or sets the date.", "DEL": "Deletes one or more files.", "DIR": "Displays a list of files and subdirectories in a directory.",
                "ECHO": "Displays messages.", "EXIT": "Quits the CMD.EXE program (command interpreter).", "FIND": "Searches for a text string in files.",
                "MD": "Creates a directory.", "MOVE": "Moves files and renames files and directories.", "PATH": "Displays the search path for executable files.",
                "RD": "Removes a directory.", "REG": "Registry editor (query/add/delete).", "REN": "Renames a file or files.", "SET": "Displays, sets, or removes environment variables.",
                "TASKLIST": "Displays all running tasks.", "TIME": "Displays the system time.", "TREE": "Graphically displays the directory structure.",
                "TYPE": "Displays the contents of a text file.", "VER": "Displays the Windows version.", "WINGET": "Windows Package Manager.", "POWERSHELL": "Starts a PowerShell session."}
        return "For more information on a specific command, type HELP command-name\n" + "\n".join(f"{k:<16}{v}" for k, v in info.items())

    # ---------------------------------------------------- PowerShell
    def _row(self, nm, n):
        mode = "d-----" if n.kind == "d" else "-a----"
        ts = time.strftime("%m/%d/%Y %I:%M %p", time.localtime(n.mtime))
        return f"{mode:<13}{ts:>20}{'' if n.kind == 'd' else n.size():>15} {nm}"

    def c_Get_ChildItem(self, a, i):
        n, pos = psargs(a, ("path", "filter", "depth", "include"))
        target = n.get("path") or (pos[0] if pos else ".")
        ap = self.inpath(target)
        root = self.vfs.get(ap)
        rec = "recurse" in n or "r" in n
        flt = n.get("filter") or n.get("include")
        dirs = [(p, c) for p, c in self.vfs.walk(ap) if c.kind == "d"] if rec and root.kind == "d" else [(ap, root)]
        out = []
        for p, c in dirs:
            if c.kind == "d":
                items = [(k, v) for k, v in sorted(c.children.items(), key=lambda kv: kv[0].lower()) if not flt or fnmatch.fnmatch(k.lower(), flt.lower())]
                where = p
            else:
                items, where = [(posixpath.basename(p), c)], posixpath.dirname(p) or "/"
            if "name" in n:
                out += [k for k, _ in items]
                continue
            if not items:
                continue
            out += ["", f"    Directory: {self.outpath(self.vfs.canon(where))}", "", f"{'Mode':<13}{'LastWriteTime':>20}{'Length':>15} Name",
                    f"{'----':<13}{'-------------':>20}{'------':>15} ----"] + [self._row(k, v) for k, v in items]
        return "\n".join(out) + "\n"

    def c_Set_Location(self, a, i):
        n, pos = psargs(a, ("path",))
        p = self.inpath(n.get("path") or (pos[0] if pos else "~"))
        if self.vfs.get(p).kind != "d":
            raise CmdError("Set-Location : Cannot find path because it does not exist.")
        self.cwd = self.vfs.canon(p)

    def c_Get_Location(self, a, i):
        return f"\nPath\n----\n{self.outpath(self.cwd)}\n"

    def c_Get_Content(self, a, i):
        n, pos = psargs(a, ("path", "tail", "totalcount", "head"))
        txt = self.read(n.get("path") or pos[0])
        lines = txt.splitlines()
        if "tail" in n:
            lines = lines[-int(n["tail"]):]
        if "totalcount" in n or "head" in n:
            lines = lines[:int(n.get("totalcount") or n.get("head"))]
        return "\n".join(lines)

    def _setc(self, a, append):
        n, pos = psargs(a, ("path", "value"))
        path = n.get("path") or (pos[0] if pos else None)
        val = n.get("value") or (pos[1] if len(pos) > 1 else "")
        if not path:
            raise CmdError("Set-Content : Cannot bind argument to parameter 'Path'.")
        self.vfs.write(self.inpath(path), str(val) + "\r\n", append=append, owner=self.user)

    def c_Set_Content(self, a, i):
        self._setc(a, False)

    def c_Add_Content(self, a, i):
        self._setc(a, True)

    def c_New_Item(self, a, i):
        n, pos = psargs(a, ("path", "itemtype", "name", "value"))
        path = n.get("path") or (pos[0] if pos else ("." if "name" in n else None))
        if not path:
            raise CmdError("New-Item : Cannot bind argument to parameter 'Path'.")
        if "name" in n:
            path = path.rstrip("\\/") + "\\" + n["name"]
        ap = self.inpath(path)
        if self.vfs.exists(ap):
            raise CmdError(f"New-Item : An item with the specified name {self.outpath(ap)} already exists.")
        if str(n.get("itemtype", "file")).lower().startswith("dir"):
            node = self.vfs.mkdir(ap, owner=self.user)
        else:
            node = self.vfs.write(ap, str(n.get("value", "")), owner=self.user)
        return f"\n    Directory: {self.outpath(posixpath.dirname(ap) or '/')}\n\n{'Mode':<13}{'LastWriteTime':>20}{'Length':>15} Name\n{self._row(posixpath.basename(ap), node)}\n"

    def c_Remove_Item(self, a, i):
        n, pos = psargs(a, ("path",))
        for p in ([n["path"]] if "path" in n else pos):
            ap = self.inpath(p)
            node = self.vfs.get(ap)
            if node.kind == "d" and node.children and not ("recurse" in n or "r" in n):
                raise CmdError("Remove-Item : The item has children and the Recurse parameter was not specified.")
            self.vfs.remove(ap, True)

    def c_Copy_Item(self, a, i):
        n, pos = psargs(a, ("path", "destination"))
        src, dst = n.get("path") or pos[0], n.get("destination") or pos[-1]
        return self.c_copy([src, dst], i) and ""

    def c_Move_Item(self, a, i):
        n, pos = psargs(a, ("path", "destination"))
        self.c_move([n.get("path") or pos[0], n.get("destination") or pos[-1]], i)

    def c_Test_Path(self, a, i):
        n, pos = psargs(a, ("path",))
        return "True" if self.vfs.exists(self.inpath(n.get("path") or pos[0])) else "False"

    def c_Write_Output(self, a, i):
        return " ".join(a) + "\n"

    def c_Write_Host(self, a, i):
        n, pos = psargs(a, ("foregroundcolor", "backgroundcolor", "separator"))
        return " ".join(pos) + "\n"

    def c_Clear_Host(self, a, i):
        return self.c_clear(a, i)

    def c_Get_Date(self, a, i):
        return "\n" + time.strftime("%A, %B %d, %Y %I:%M:%S %p") + "\n"

    def c_Get_Process(self, a, i):
        rows = ["", "Handles  NPM(K)    PM(K)      WS(K)     CPU(s)     Id  SI ProcessName", "-------  ------    -----      -----     ------     --  -- -----------"]
        for p in self.procs():
            m = int(p[3])
            rows.append(f"{m // 40:>7} {m // 800:>7} {m // 2:>8} {m:>10} {int(p[0]) % 7 * 0.31:>10.2f} {p[0]:>6} {0 if int(p[0]) < 700 else 1:>3} {p[4].replace('.exe', '')}")
        return "\n".join(rows) + "\n"

    def c_Stop_Process(self, a, i):
        n, pos = psargs(a, ("id", "name"))
        targets = [n["id"]] if "id" in n else [p[0] for p in self.procs() if p[4].lower().replace(".exe", "") == str(n.get("name", pos[0] if pos else "")).lower().replace(".exe", "")]
        if not targets:
            raise CmdError("Stop-Process : Cannot find a process with the specified name or id.")
        for t in targets:
            r = self.core.request("KILL", t)
            if r.startswith("err"):
                raise CmdError(f"Stop-Process : Cannot stop process (Id {t}) because {'Access is denied' if 'prot' in r else 'it was not found'}.")

    def c_Get_Service(self, a, i):
        rows = ["", "Status   Name               DisplayName", "------   ----               -----------"]
        rows += [f"{st:<8} {n:<18} {d}" for n, d, st in SERVICES]
        return "\n".join(rows) + "\n"

    def c_Get_Command(self, a, i):
        n = a[0].lower() if a else ""
        hits = [k for k in self.cmds if "-" in k and n in k]
        return "\nCommandType     Name\n-----------     ----\n" + "\n".join(f"Cmdlet          {h}" for h in sorted(hits)) + "\n"

    def c_Get_Help(self, a, i):
        return f"NAME\n    {a[0] if a else 'Get-Help'}\n\nSYNOPSIS\n    POP simulated help. Try: Get-Command"

    def c_Select_String(self, a, i):
        n, pos = psargs(a, ("pattern", "path"))
        pat = re.compile(n.get("pattern") or pos[0], re.I)
        path = n.get("path") or (pos[1] if len(pos) > 1 else None)
        txt = self.read(path) if path else (i or "")
        return "\n".join((f"{path}:{k}:" if path else "") + l for k, l in enumerate(txt.splitlines(), 1) if pat.search(l))

    def c_Get_ItemProperty(self, a, i):
        n, pos = psargs(a, ("path", "name"))
        key = self.longkey(n.get("path") or pos[0])
        res = self.core.request("REGQ", key)
        if res == "err":
            raise CmdError(f"Get-ItemProperty : Cannot find path '{key}' because it does not exist.")
        vals = [l.split("\t") for l in res.splitlines() if l.startswith("V")]
        w = max((len(v[1]) for v in vals), default=1)
        return "\n" + "\n".join(f"{v[1]:<{w}} : {v[3]}" for v in vals) + "\n"
