"""POP Linux: FHS tree, kernel boot log, systemd-style init, apt-like packages.

Modelled on real Linux conventions (Filesystem Hierarchy Standard, systemd unit
files, dmesg format, coreutils/util-linux output).  Not the kernel source itself:
it is a sandboxed simulation that behaves like Linux inside Termux.
"""
import time

from .posix import PosixShell, rwx
from .shell import CmdError, col, nap, parse_flags, progress_bar

BIN = "POPBIN"
# unit, description, process name, memory(kB)
SERVICES = [
    ("systemd-journald.service", "Journal Service", "systemd-journald", 18000),
    ("systemd-udevd.service", "Rule-based Manager for Device Events and Files", "systemd-udevd", 9000),
    ("systemd-tmpfiles-setup.service", "Create Volatile Files and Directories", None, 0),
    ("systemd-networkd.service", "Network Configuration", "systemd-networkd", 11000),
    ("systemd-resolved.service", "Network Name Resolution", "systemd-resolved", 13000),
    ("dbus.service", "D-Bus System Message Bus", "dbus-daemon", 6000),
    ("systemd-logind.service", "User Login Management", "systemd-logind", 7500),
    ("cron.service", "Regular background program processing daemon", "cron", 2800),
    ("ssh.service", "OpenBSD Secure Shell server", "sshd", 7200),
]
KERNEL_LOG = [
    "Booting Linux on physical CPU 0x0000000000 [0x410fd034]",
    "Linux version 6.1.0-pop (pop@build) (aarch64-linux-gnu-gcc 12.2.0) #1 SMP PREEMPT_DYNAMIC",
    "Machine model: POP Virtual Board (Termux sandbox)",
    "efi: UEFI not found.",
    "Zone ranges:  DMA32 [mem 0x0000000040000000-0x00000000ffffffff]  Normal empty",
    "Memory: 8101376K/8388608K available (14272K kernel code, 2850K rwdata, 9748K rodata)",
    "rcu: Preemptible hierarchical RCU implementation.",
    "clocksource: arch_sys_counter: mask: 0xffffffffffffff max_cycles: 0x1cd42e208c",
    "Console: colour dummy device 80x25",
    "pid_max: default: 32768 minimum: 301",
    "Mount-cache hash table entries: 16384 (order: 5, 131072 bytes, linear)",
    "smp: Bringing up secondary CPUs ... smp: Brought up 1 node, 8 CPUs",
    "NET: Registered PF_INET protocol family",
    "VFS: Disk quotas dquot_6.6.0",
    "EXT4-fs (vda1): mounted filesystem with ordered data mode. Quota mode: none.",
    "VFS: Mounted root (ext4 filesystem) readonly on device 254:1.",
    "Freeing unused kernel memory: 5376K",
    "Run /sbin/init as init process",
    "systemd[1]: systemd 252 running in system mode (+PAM +AUDIT +SELINUX +APPARMOR)",
    "systemd[1]: Detected architecture arm64.",
]
PKGS = {   # name: (description, version, size kB)
    "neofetch": ("Shows Linux System Information with Distribution Logo", "7.1.0-4", 230),
    "htop": ("interactive processes viewer", "3.2.2-2", 410),
    "cowsay": ("configurable talking cow", "3.03+dfsg2-8", 90),
    "git": ("fast, scalable, distributed revision control system", "1:2.39.2-1", 8200),
    "curl": ("command line tool for transferring data with URL syntax", "7.88.1-10", 410),
    "python3": ("interactive high-level object-oriented language", "3.11.2-1", 24000),
    "gcc": ("GNU C compiler", "4:12.2.0-3", 31000),
    "make": ("utility for directing compilation", "4.3-4.1", 400),
    "figlet": ("make large character ASCII banners out of ordinary text", "2.2.5-3", 280),
    "tree": ("displays directory tree, in color", "2.1.0-1", 110),
    "nano": ("small, friendly text editor", "7.2-1", 780),
    "vim": ("Vi IMproved - enhanced vi editor", "2:9.0.1378-2", 3500),
}
PREINSTALLED = ["tree", "nano", "vim"]
ETC_HOSTS = "127.0.0.1\tlocalhost\n127.0.1.1\tpop\n::1\tlocalhost ip6-localhost ip6-loopback\n"
BASHRC = ("# ~/.bashrc: executed by bash for non-login shells.\nalias ll='ls -l'\nalias la='ls -la'\n"
          "alias ..='cd ..'\nexport EDITOR=nano\n")
HELLO = "#!/bin/bash\necho \"Hello from POP Linux, $USER!\"\necho \"Kernel: $(uname -r)\"\n"


def unit_file(unit, desc, proc):
    return (f"[Unit]\nDescription={desc}\nAfter=network.target\n\n[Service]\n"
            f"ExecStart=/usr/sbin/{proc or unit.split('.')[0]}\nRestart=on-failure\n\n"
            f"[Install]\nWantedBy=multi-user.target\n")


class LinuxShell(PosixShell):
    os_name = "linux"
    shell_name = "bash"
    uid = 1000
    home_dir = "/home/user"
    uname_info = ("Linux", "pop", "6.1.0-pop", "#1 SMP PREEMPT_DYNAMIC Mon Nov 16 2026", "aarch64")

    @classmethod
    def generate(cls, vfs):
        """Generator: build the filesystem, yielding a stage name after each step."""
        yield "Creating Filesystem Hierarchy Standard directories"
        vfs.populate("/", {d: {} for d in "bin boot dev etc home lib media mnt opt proc root run sbin srv sys tmp usr var".split()})
        for d in ("usr/bin usr/sbin usr/lib usr/share/doc usr/share/man usr/local/bin usr/local/sbin usr/local/lib "
                  "var/log var/lib/dpkg var/cache/apt var/tmp var/spool/cron run/systemd boot/grub "
                  "etc/systemd/system etc/apt etc/ssh etc/cron.d home/user/Documents home/user/Downloads").split():
            vfs.mkdir("/" + d, parents=True, owner="root")
        vfs.get("/tmp").mode = 0o1777
        yield "Installing coreutils, util-linux and shell binaries"
        for b in "ls cat cp mv rm mkdir rmdir echo pwd date uname chmod chown touch sleep sync true false ps kill bash sh dash".split():
            vfs.write(f"/bin/{b}", BIN + f" {b}", mode=0o755, owner="root")
        for b in "grep find head tail wc sort uniq stat env id whoami basename dirname tree which nano vim apt dpkg python3 sudo".split():
            vfs.write(f"/usr/bin/{b}", BIN + f" {b}", mode=0o755, owner="root")
        for b in "init reboot poweroff shutdown ip ldconfig".split():
            vfs.write(f"/sbin/{b}", BIN + f" {b}", mode=0o755, owner="root")
        vfs.write("/usr/bin/systemctl", BIN + " systemctl", mode=0o755, owner="root")
        vfs.write("/boot/vmlinuz-6.1.0-pop", BIN + " kernel image", owner="root")
        vfs.write("/boot/grub/grub.cfg", "set default=0\nset timeout=2\nmenuentry 'POP Linux 1.0' {\n  linux /boot/vmlinuz-6.1.0-pop root=/dev/vda1 ro quiet\n}\n", owner="root")
        yield "Writing /etc configuration (os-release, passwd, fstab, systemd units)"
        etc = {
            "os-release": 'PRETTY_NAME="POP Linux 1.0 (Aurora)"\nNAME="POP Linux"\nVERSION_ID="1.0"\nVERSION="1.0 (Aurora)"\nID=pop\nID_LIKE=debian\n',
            "hostname": "pop\n", "hosts": ETC_HOSTS, "issue": "POP Linux 1.0 \\n \\l\n",
            "motd": "Welcome to POP Linux. This is a sandboxed simulation running inside Termux.\n",
            "passwd": "root:x:0:0:root:/root:/bin/bash\ndaemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin\nuser:x:1000:1000:POP User,,,:/home/user:/bin/bash\n",
            "group": "root:x:0:\nsudo:x:27:user\nuser:x:1000:\n", "shells": "/bin/sh\n/bin/bash\n",
            "fstab": "# <file system> <mount point> <type> <options> <dump> <pass>\n/dev/vda1 / ext4 errors=remount-ro 0 1\nproc /proc proc defaults 0 0\n",
            "resolv.conf": "nameserver 1.1.1.1\nnameserver 8.8.8.8\n", "timezone": "UTC\n",
            "profile": "# /etc/profile\nexport PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n",
            "apt": {"sources.list": "deb http://deb.pop.invalid/pop stable main\n"},
            "ssh": {"sshd_config": "Port 22\nPermitRootLogin no\nPasswordAuthentication yes\n"},
            "systemd": {"system": {u: unit_file(u, d, p) for u, d, p, _ in SERVICES}},
        }
        vfs.populate("/etc", etc)
        vfs.write("/etc/shadow", "root:*:19000:0:99999:7:::\nuser:!:19000:0:99999:7:::\n", mode=0o640, owner="root")
        yield "Populating /home, /root and /var"
        vfs.write("/home/user/.bashrc", BASHRC, owner="user")
        vfs.write("/home/user/.profile", "# ~/.profile\n", owner="user")
        vfs.write("/home/user/hello.sh", HELLO, mode=0o755, owner="user")
        vfs.write("/home/user/README.txt", "Welcome to POP Linux!\nTry: ls -l, tree, apt install neofetch, systemctl status cron, cat /proc/cpuinfo\n", owner="user")
        for _, nd in vfs.walk("/home/user"):
            nd.owner = "user"
        vfs.write("/root/.bashrc", BASHRC, owner="root")
        vfs.write("/var/log/syslog", "", owner="root")
        vfs.write("/var/log/kern.log", "".join(f"[{k * 0.0137:12.6f}] {l}\n" for k, l in enumerate(KERNEL_LOG)), owner="root")
        vfs.write("/var/lib/dpkg/pop-installed", "".join(f"{p} {PKGS[p][1]}\n" for p in PREINSTALLED), owner="root")
        for p in PREINSTALLED:
            vfs.write(f"/usr/bin/{p}", BIN + f" {p}", mode=0o755, owner="root")
        for dev in ("null", "zero", "tty", "random", "urandom", "console"):
            vfs.write(f"/dev/{dev}", "", owner="root")
        yield "Mounting virtual filesystems (/proc, /sys)"
        for f in ("cpuinfo", "meminfo", "version", "uptime", "loadavg", "cmdline", "mounts"):
            vfs.write(f"/proc/{f}", "", owner="root")
        vfs.mkdir("/sys/class/net", parents=True, owner="root")
        vfs.mkdir("/sys/devices/system/cpu", parents=True, owner="root")

    # ---------------------------------------------------------- boot
    def attach(self, first):
        v = self.vfs
        v.add_provider("/proc/version", lambda: "Linux version 6.1.0-pop (pop@build) #1 SMP PREEMPT_DYNAMIC\n")
        v.add_provider("/proc/uptime", lambda: f"{self.uptime_s()}.00 {self.uptime_s() * 7}.00\n")
        v.add_provider("/proc/loadavg", lambda: "0.08 0.03 0.01 1/120 4242\n")
        v.add_provider("/proc/cmdline", lambda: "root=/dev/vda1 ro quiet\n")
        v.add_provider("/proc/mounts", lambda: "/dev/vda1 / ext4 rw,relatime 0 0\nproc /proc proc rw 0 0\ntmpfs /tmp tmpfs rw 0 0\n")
        v.add_provider("/proc/cpuinfo", lambda: "".join(
            f"processor\t: {n}\nBogoMIPS\t: 38.40\nFeatures\t: fp asimd evtstrm aes pmull sha1 sha2 crc32\n"
            f"CPU implementer\t: 0x41\nCPU architecture: 8\nCPU part\t: 0xd03\n\n" for n in range(8)))

        def meminfo():
            t, u, f = (int(x) for x in self.core.request("MEM").split("\t"))
            return (f"MemTotal:       {t:>8} kB\nMemFree:        {f:>8} kB\nMemAvailable:   {f:>8} kB\n"
                    f"Buffers:          51200 kB\nCached:          614400 kB\nSwapTotal:      2097152 kB\nSwapFree:       2097152 kB\n")
        v.add_provider("/proc/meminfo", meminfo)

    def boot(self, first):
        self.attach(first)
        self.env.update({"HOME": "/home/user", "USER": "user", "LOGNAME": "user", "SHELL": "/bin/bash",
                         "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin", "PWD": self.cwd,
                         "TERM": "xterm-256color", "LANG": "C.UTF-8", "HOSTNAME": "pop"})
        self.aliases.update({"ll": "ls -l", "la": "ls -la", ".": "source"})
        self.core.request("INIT", 1, 1, 2)
        self.spawn("systemd", 0, 11000)
        self.spawn("kthreadd", 0, 0)
        self.svc = {}
        for k, l in enumerate(KERNEL_LOG):
            print(f"[{k * 0.0137 + 0.0004:12.6f}] {l}")
            nap(0.04)
        print()
        for unit, desc, proc, mem in SERVICES:
            pid = self.spawn(proc, 1, mem) if proc else 0
            self.svc[unit] = {"pid": pid, "active": True, "enabled": True, "desc": desc, "proc": proc}
            print(f"[  {col('OK', 'green')}  ] Started {desc}.")
            nap(0.1)
        print(f"[  {col('OK', 'green')}  ] Reached target {col('Multi-User System', 'bold')}.\n")
        self.pid = self.spawn("bash", 1, 3500)
        nap(0.3)
        print("POP Linux 1.0 (Aurora) pop tty1\n")
        print(self.vfs.read("/etc/motd"))
        print(f"Last login: {time.strftime('%a %b %d %H:%M:%S %Y')} on tty1")

    def prompt(self):
        return f"{col(self.user + '@' + self.host, 'green')}:{col(self.tilde(self.cwd), 'blue')}{'#' if self.user == 'root' else '$'} "

    def notfound(self, n):
        return f"bash: {n}: command not found"

    # ---------------------------------------------------- privileges
    sudo_now = False

    def is_root(self):
        return self.user == "root" or self.sudo_now

    def c_sudo(self, a, i):
        if not a:
            raise CmdError("usage: sudo command")
        self.sudo_now = True
        try:
            return self.dispatch(a, i)
        finally:
            self.sudo_now = False

    # -------------------------------------------------- system info
    def c_uname(self, a, i):
        return super().c_uname(a, i)

    def c_free(self, a, i):
        fl, _ = parse_flags(a)
        t, u, f = (int(x) for x in self.core.request("MEM").split("\t"))
        sw = 2097152
        conv = (lambda k: f"{k / 1048576:.1f}Gi" if k >= 1048576 else f"{k / 1024:.0f}Mi") if "h" in fl else str
        return ("               total        used        free      shared  buff/cache   available\n"
                f"Mem:{conv(t):>15}{conv(u):>12}{conv(f):>12}{conv(2048):>12}{conv(665600):>12}{conv(f):>12}\n"
                f"Swap:{conv(sw):>14}{conv(0):>12}{conv(sw):>12}")

    def c_df(self, a, i):
        fl, _ = parse_flags(a)
        rows = [("/dev/vda1", 61255492, 12345678, "/"), ("tmpfs", 4194304, 1024, "/tmp"), ("tmpfs", 4194304, 0, "/run")]
        h = lambda k: f"{k / 1048576:.0f}G" if k >= 1048576 else f"{k / 1024:.0f}M" if k > 1024 else f"{k}K"
        out = ["Filesystem      " + ("Size  Used Avail Use% Mounted on" if "h" in fl else "1K-blocks      Used Available Use% Mounted on")]
        for n, t, u, m in rows:
            pc = f"{u * 100 // t}%"
            out.append(f"{n:<15} " + (f"{h(t):>4} {h(u):>5} {h(t - u):>5} {pc:>4} {m}" if "h" in fl else f"{t:>9} {u:>9} {t - u:>9} {pc:>4} {m}"))
        return "\n".join(out)

    def c_lscpu(self, a, i):
        return ("Architecture:        aarch64\nCPU op-mode(s):      32-bit, 64-bit\nByte Order:          Little Endian\n"
                "CPU(s):              8\nVendor ID:           ARM\nModel name:          Cortex-A55\nBogoMIPS:            38.40")

    def c_lsblk(self, a, i):
        return ("NAME   MAJ:MIN RM  SIZE RO TYPE MOUNTPOINTS\nvda    254:0    0   64G  0 disk\n"
                "└─vda1 254:1    0   64G  0 part /")

    def c_mount(self, a, i):
        return self.vfs.read("/proc/mounts")

    def c_dmesg(self, a, i):
        return "\n".join(f"[{k * 0.0137 + 0.0004:12.6f}] {l}" for k, l in enumerate(KERNEL_LOG))

    def c_ip(self, a, i):
        return ("1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000\n"
                "    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00\n    inet 127.0.0.1/8 scope host lo\n"
                "2: wlan0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP group default qlen 1000\n"
                "    link/ether 02:50:4f:50:00:01 brd ff:ff:ff:ff:ff:ff\n    inet 192.168.1.42/24 brd 192.168.1.255 scope global dynamic wlan0")

    def c_ping(self, a, i):
        _, r = parse_flags(a)
        if not r:
            raise CmdError("ping: usage error: Destination address required")
        ip = f"93.184.{sum(map(ord, r[0])) % 200}.{sum(map(ord, r[0][::-1])) % 250 + 1}"
        print(f"PING {r[0]} ({ip}) 56(84) bytes of data.")
        for k in range(4):
            nap(0.4)
            print(f"64 bytes from {ip}: icmp_seq={k + 1} ttl=57 time={20 + (k * 7) % 11}.{k}3 ms")
        return f"\n--- {r[0]} ping statistics ---\n4 packets transmitted, 4 received, 0% packet loss, time 3004ms"

    def c_top(self, a, i):
        pr = self.procs()
        t, u, f = (int(x) for x in self.core.request("MEM").split("\t"))
        head = (f"top - {time.strftime('%H:%M:%S')} up {self.uptime_s() // 60} min,  1 user,  load average: 0.08, 0.03, 0.01\n"
                f"Tasks: {len(pr):>3} total,   {sum(p[2] == 'R' for p in pr)} running, {sum(p[2] == 'S' for p in pr)} sleeping\n"
                f"MiB Mem : {t / 1024:8.1f} total, {f / 1024:8.1f} free, {u / 1024:8.1f} used\n\n"
                "    PID USER      PR  NI    VIRT    RES  S  %CPU  %MEM COMMAND")
        return head + "\n" + "\n".join(f"{p[0]:>7} {('root' if int(p[1]) < 2 else self.user):<9} 20   0 {int(p[3]) * 4:>7} {p[3]:>6}  {p[2]}   0.{int(p[3]) % 9}   {int(p[3]) * 100 / t:.1f} {p[4]}" for p in pr)

    def c_shutdown(self, a, i):
        print("Shutdown scheduled for now, use 'shutdown -c' to cancel.")
        nap(0.5)
        return self.c_poweroff(a, i)

    # --------------------------------------------------------- systemd
    def c_systemctl(self, a, i):
        fl, r = parse_flags(a)
        if not r:
            raise CmdError("systemctl: missing command")
        act, units = r[0], r[1:]
        if act in ("list-units", "list-unit-files"):
            rows = ["  UNIT                            LOAD   ACTIVE SUB     DESCRIPTION"]
            for u, s in self.svc.items():
                rows.append(f"  {u:<31} loaded {'active' if s['active'] else 'inactive'} {'running' if s['active'] else 'dead':<7} {s['desc']}")
            return "\n".join(rows)
        if act == "is-active":
            return "active" if self.svc.get(self._unit(units)) and self.svc[self._unit(units)]["active"] else "inactive"
        if not units:
            raise CmdError(f"Too few arguments.")
        u = self._unit(units)
        s = self.svc.get(u)
        if act in ("start", "stop", "restart", "enable", "disable") and not self.is_root():
            raise CmdError("==== AUTHENTICATING FOR org.freedesktop.systemd1.manage-units ====\nFailed to " + act + f" {u}: Access denied (try with sudo)")
        if s is None:
            raise CmdError(f"Failed to {act} {u}: Unit {u} not found.")
        if act == "start" or act == "restart":
            if s["active"] and act == "restart" and s["pid"]:
                self.core.request("KILL", s["pid"])
            if not s["active"] or act == "restart":
                s["pid"] = self.spawn(s["proc"], 1, 4000) if s["proc"] else 0
            s["active"] = True
        elif act == "stop":
            if s["pid"]:
                self.core.request("KILL", s["pid"])
            s["active"], s["pid"] = False, 0
        elif act in ("enable", "disable"):
            s["enabled"] = act == "enable"
            return f"Created symlink /etc/systemd/system/multi-user.target.wants/{u}." if s["enabled"] else f"Removed /etc/systemd/system/multi-user.target.wants/{u}."
        elif act == "status":
            dot = col("●", "green") if s["active"] else "○"
            return (f"{dot} {u} - {s['desc']}\n     Loaded: loaded (/lib/systemd/system/{u}; {'enabled' if s['enabled'] else 'disabled'}; preset: enabled)\n"
                    f"     Active: {'active (running)' if s['active'] else 'inactive (dead)'} since {time.strftime('%a %Y-%m-%d %H:%M:%S UTC')}\n"
                    f"   Main PID: {s['pid']} ({s['proc']})" if s["active"] else f"{dot} {u} - {s['desc']}\n     Active: inactive (dead)")
        else:
            raise CmdError(f"Unknown command verb {act}.")

    def _unit(self, units):
        u = units[0] if units else ""
        return u if "." in u else u + ".service"

    def c_service(self, a, i):
        if len(a) < 2:
            raise CmdError("Usage: service < option > | --status-all | [ service_name [ command | --full-restart ] ]")
        return self.c_systemctl([a[1], a[0]], i)

    def c_journalctl(self, a, i):
        stamp = time.strftime("%b %d %H:%M:%S")
        return "\n".join(f"{stamp} pop systemd[1]: Started {s['desc']}." for s in self.svc.values())

    # ------------------------------------------------------------- apt
    def _installed(self):
        return dict(l.split(" ", 1) for l in self.vfs.read("/var/lib/dpkg/pop-installed").splitlines() if l)

    def c_apt(self, a, i):
        fl, r = parse_flags(a)
        if not r:
            return "apt 2.6.1 (arm64)\nUsage: apt [options] command\n  list, search, show, update, install, remove, upgrade"
        act, pk = r[0], r[1:]
        inst = self._installed()
        if act == "list":
            return "Listing... Done\n" + "\n".join(f"{n}/stable {PKGS[n][1] if n in PKGS else v} arm64 [installed]" for n, v in sorted(inst.items())) if "installed" in fl else \
                "Listing... Done\n" + "\n".join(f"{n}/stable {v[1]} arm64" + (" [installed]" if n in inst else "") for n, v in sorted(PKGS.items()))
        if act == "search":
            q = pk[0] if pk else ""
            return "Sorting... Done\nFull Text Search... Done\n" + "\n".join(f"{n}/stable {v[1]} arm64\n  {v[0]}\n" for n, v in sorted(PKGS.items()) if q in n or q in v[0])
        if act == "show":
            if not pk or pk[0] not in PKGS:
                raise CmdError(f"E: No packages found")
            d, v, s = PKGS[pk[0]]
            return f"Package: {pk[0]}\nVersion: {v}\nInstalled-Size: {s} kB\nDescription: {d}"
        if act in ("update", "install", "remove", "upgrade", "purge", "autoremove") and not self.is_root():
            raise CmdError("E: Could not open lock file /var/lib/dpkg/lock-frontend - open (13: Permission denied)\n"
                           "E: Unable to acquire the dpkg frontend lock, are you root?")
        if act == "update":
            for k, h in enumerate(("InRelease [110 kB]", "Packages [8,540 kB]", "Translation-en [6,102 kB]"), 1):
                print(f"Get:{k} http://deb.pop.invalid/pop stable {h}")
                nap(0.25)
            return "Fetched 14.8 MB in 1s (11.2 MB/s)\nReading package lists... Done\nAll packages are up to date."
        if act == "upgrade":
            return "Reading package lists... Done\nBuilding dependency tree... Done\n0 upgraded, 0 newly installed, 0 to remove and 0 not upgraded."
        if act in ("install", "remove", "purge") and not pk:
            raise CmdError("E: No packages specified")
        if act == "install":
            for n in pk:
                if n not in PKGS:
                    raise CmdError(f"E: Unable to locate package {n}")
            new = [n for n in pk if n not in inst]
            if not new:
                return "\n".join(f"{n} is already the newest version ({PKGS[n][1]})." for n in pk)
            print("Reading package lists... Done\nBuilding dependency tree... Done\nThe following NEW packages will be installed:\n  " + " ".join(new))
            print(f"0 upgraded, {len(new)} newly installed, 0 to remove and 0 not upgraded.")
            for n in new:
                print(f"Get:1 http://deb.pop.invalid/pop stable/main arm64 {n} arm64 {PKGS[n][1]} [{PKGS[n][2]} kB]")
                progress_bar(f"Unpacking {n}", 20, 0.02)
                self.vfs.write(f"/usr/bin/{n}", BIN + f" {n}", mode=0o755, owner="root")
                self.vfs.write("/var/lib/dpkg/pop-installed", f"{n} {PKGS[n][1]}\n", append=True, owner="root")
                print(f"Setting up {n} ({PKGS[n][1]}) ...")
            return ""
        if act in ("remove", "purge"):
            kept = []
            for n in pk:
                if n in inst:
                    self.vfs.remove(f"/usr/bin/{n}") if self.vfs.exists(f"/usr/bin/{n}") else None
                    print(f"Removing {n} ({inst.pop(n)}) ...")
                else:
                    print(f"Package '{n}' is not installed, so not removed")
            self.vfs.write("/var/lib/dpkg/pop-installed", "".join(f"{k} {v}\n" for k, v in inst.items()), owner="root")
            return ""
        raise CmdError(f"E: Invalid operation {act}")

    c_apt_get = c_apt

    def c_dpkg(self, a, i):
        fl, _ = parse_flags(a)
        if "l" in fl or "list" in fl:
            return "Desired=Unknown/Install/Remove/Purge/Hold\n||/ Name           Version      Architecture Description\n+++-==============-============-============-=================\n" + \
                "\n".join(f"ii  {n:<14} {v:<12} arm64        {PKGS[n][0] if n in PKGS else ''}" for n, v in sorted(self._installed().items()))
        raise CmdError("dpkg: error: need an action option")

    def _need(self, pkg):
        if not self.vfs.exists(f"/usr/bin/{pkg}"):
            raise CmdError(f"Command '{pkg}' not found, but can be installed with:\nsudo apt install {pkg}")

    # ----------------------------------------------- installable programs
    def c_neofetch(self, a, i):
        self._need("neofetch")
        t, u, f = (int(x) for x in self.core.request("MEM").split("\t"))
        logo = ["   .--.   ", "  |o_o |  ", "  |:_/ |  ", " //   \\ \\ ", "(|     | )", "/'\\_   _/`\\", "\\___)=(___/"]
        info = [f"{col('user@pop', 'green')}", "-" * 8, "OS: POP Linux 1.0 aarch64", "Kernel: 6.1.0-pop", f"Uptime: {self.uptime_s() // 60} mins",
                f"Packages: {len(self._installed())} (dpkg)", "Shell: bash 5.2", f"Memory: {u // 1024}MiB / {t // 1024}MiB"]
        return "\n".join(f"{col(logo[k] if k < len(logo) else ' ' * 11, 'yellow')}  {info[k] if k < len(info) else ''}" for k in range(max(len(logo), len(info))))

    def c_htop(self, a, i):
        self._need("htop")
        return self.c_top(a, i)

    def c_cowsay(self, a, i):
        self._need("cowsay")
        msg = " ".join(a) or (i or "Moo!").strip()
        bar = "-" * (len(msg) + 2)
        return f" _{bar}\n< {msg} >\n -{bar}\n        \\   ^__^\n         \\  (oo)\\_______\n            (__)\\       )\\/\\\n                ||----w |\n                ||     ||"

    def c_figlet(self, a, i):
        self._need("figlet")
        t = " ".join(a).upper()
        return f"+{'-' * (len(t) * 2 + 1)}+\n| {' '.join(t)} |\n+{'-' * (len(t) * 2 + 1)}+"
