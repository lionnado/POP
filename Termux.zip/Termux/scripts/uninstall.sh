#!/usr/bin/env bash
BINDIR="${PREFIX:-$HOME/.local}/bin"
rm -f "$BINDIR/POP" "$BINDIR/pop"; rm -rf "$HOME/.pop"
echo "POP removed (delete the Termux folder to remove the sources)."
