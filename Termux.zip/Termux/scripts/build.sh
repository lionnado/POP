#!/usr/bin/env bash
# Compile the C++ UI, the C firmware screen and the Rust engine.
set -e
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"; mkdir -p bin
CXX="${CXX:-clang++}"; command -v "$CXX" >/dev/null || CXX=g++
CC="${CC:-clang}";     command -v "$CC"  >/dev/null || CC=gcc
echo "[build] C++ UI      -> bin/pop-ui";  "$CXX" -O2 -std=c++17 -Wall src/ui/pop_ui.cpp -o bin/pop-ui -lncurses
echo "[build] C firmware  -> bin/popsys";  "$CC"  -O2 -Wall src/sys/popsys.c -o bin/popsys
if command -v cargo >/dev/null; then
  echo "[build] Rust engine -> bin/popcore"
  if (cd rust/popcore && cargo build --release); then
    cp rust/popcore/target/release/popcore bin/popcore
  else
    echo "[build] Rust build failed - POP will use the Python fallback engine."
  fi
else
  echo "[build] cargo not found - POP will use the Python fallback engine."
fi
chmod +x bin/* 2>/dev/null || true
echo "[build] done."
