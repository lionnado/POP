#!/usr/bin/env bash
# Make the POP / pop commands available on PATH.
set -e
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BINDIR="${PREFIX:-$HOME/.local}/bin"; mkdir -p "$BINDIR"
chmod +x "$ROOT/bin/POP"
ln -sf "$ROOT/bin/POP" "$BINDIR/POP"
ln -sf "$ROOT/bin/POP" "$BINDIR/pop"
mkdir -p "$HOME/.pop"
echo "[install] linked POP -> $BINDIR/POP"
