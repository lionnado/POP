/*
 * pop_ui.cpp - POP launcher (C++17 / ncurses, touch + mouse + keyboard).
 *
 * Shows three OS buttons.  Tap (or press a key) to select: the button grows
 * and a description appears.  Tap the selected button again (or press Enter)
 * to run the loading sequence.  The process then exits with a code that the
 * bin/POP wrapper turns into "start environment X":
 *      0 = quit,  10 = Linux,  11 = Windows,  12 = macOS
 *
 * Termux delivers screen taps as xterm mouse events, which ncurses reports as
 * BUTTON1_PRESSED / BUTTON1_CLICKED.
 */
#include <ncurses.h>
#include <algorithm>
#include <chrono>
#include <clocale>
#include <cstdlib>
#include <string>
#include <vector>

namespace {

constexpr int N = 3;
constexpr int COLLAPSED_H = 3;

struct OsInfo {
    const char *name;               // button label
    const char *tag;                // one-line tagline (collapsed view)
    int color;                      // ncurses colour pair
    const char *desc;               // shown when the button is expanded
    std::vector<const char *> stages;   // loading-screen messages
};

const OsInfo OSES[N] = {
    {"LINUX", "open-source, UNIX-like", 1,
     "A Linux environment modelled on the real thing: the FHS directory tree, kernel boot log, a "
     "systemd-style init that starts units, coreutils-style commands, /proc, an apt-style package "
     "manager and a bash-like shell. Fully sandboxed inside Termux.",
     {"Loading kernel image", "Mounting root filesystem", "Generating FHS hierarchy", "Starting systemd units",
      "Seeding /etc and /proc", "Starting package manager", "Spawning login shell"}},
    {"WINDOWS", "NT-style cmd + PowerShell", 2,
     "A Windows NT-style environment: the C:\\ drive with Windows\\System32, Program Files and Users, "
     "cmd.exe and PowerShell cmdlets, tasklist/taskkill, and a registry (HKLM/HKCU) powered by the "
     "Rust engine.",
     {"Starting boot manager", "Loading ntoskrnl", "Mounting C:\\ volume", "Loading registry hives",
      "Starting services.exe", "Loading user profile", "Starting command prompt"}},
    {"MAC", "Darwin / zsh terminal", 3,
     "A macOS (Darwin) style environment: /Applications, /Library, /System and /Users, a zsh prompt, "
     "Homebrew, sw_vers, defaults, launchctl and system_profiler - the familiar Terminal.app feel.",
     {"Loading XNU kernel", "Mounting APFS volume", "Starting launchd", "Loading frameworks",
      "Starting WindowServer", "Opening user session", "Launching zsh"}},
};

const char *LOGO[5] = {
    " ____   ___  ____  ",
    "|  _ \\ / _ \\|  _ \\ ",
    "| |_) | | | | |_) |",
    "|  __/| |_| |  __/ ",
    "|_|    \\___/|_|    ",
};

struct Rect { int y = 0, x = 0, h = 0, w = 0; };

Rect rects[N];
float curH[N] = {COLLAPSED_H, COLLAPSED_H, COLLAPSED_H};

long nowMs() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

std::vector<std::string> wrap(const std::string &s, int w) {
    std::vector<std::string> out;
    std::string line, word;
    for (size_t i = 0; i <= s.size(); ++i) {
        if (i == s.size() || s[i] == ' ') {
            if (!word.empty()) {
                if (!line.empty() && static_cast<int>(line.size() + 1 + word.size()) > w) {
                    out.push_back(line);
                    line.clear();
                }
                if (!line.empty()) line += ' ';
                line += word;
                word.clear();
            }
        } else {
            word += s[i];
        }
    }
    if (!line.empty()) out.push_back(line);
    return out;
}

int btnWidth() { return std::max(20, std::min(COLS - 2, 62)); }

int targetHeight(int i, int sel) {
    if (i != sel) return COLLAPSED_H;
    // borders(2) + header(1) + rule(1) + description + boot button(3)
    return 4 + static_cast<int>(wrap(OSES[i].desc, btnWidth() - 4).size()) + 3;
}

void box(int y, int x, int h, int w) {
    if (h < 2 || w < 2) return;
    mvaddch(y, x, ACS_ULCORNER);
    mvhline(y, x + 1, ACS_HLINE, w - 2);
    mvaddch(y, x + w - 1, ACS_URCORNER);
    for (int r = 1; r < h - 1; ++r) {
        mvaddch(y + r, x, ACS_VLINE);
        mvaddch(y + r, x + w - 1, ACS_VLINE);
    }
    mvaddch(y + h - 1, x, ACS_LLCORNER);
    mvhline(y + h - 1, x + 1, ACS_HLINE, w - 2);
    mvaddch(y + h - 1, x + w - 1, ACS_LRCORNER);
}

void centered(int y, int x, int w, const std::string &s, int attr = 0) {
    if (y < 0 || y >= LINES) return;
    int px = x + std::max(0, (w - static_cast<int>(s.size())) / 2);
    attron(attr);
    mvaddnstr(y, px, s.c_str(), std::max(0, w));
    attroff(attr);
}

int drawTitle() {
    if (LINES >= 32) {
        for (int r = 0; r < 5; ++r) centered(1 + r, 0, COLS, LOGO[r], COLOR_PAIR(4) | A_BOLD);
        centered(6, 0, COLS, "multi-OS terminal simulator", COLOR_PAIR(5));
        return 8;
    }
    centered(0, 0, COLS, "P O P", COLOR_PAIR(4) | A_BOLD);
    centered(1, 0, COLS, "multi-OS terminal simulator", COLOR_PAIR(5));
    return 3;
}

void drawButton(int i, int sel) {
    const Rect &r = rects[i];
    const OsInfo &o = OSES[i];
    const bool on = (i == sel);
    const int attr = COLOR_PAIR(o.color) | (on ? A_BOLD : 0);
    attron(attr);
    box(r.y, r.x, r.h, r.w);
    attroff(attr);
    if (r.h < 3) return;

    // header row: spaced-out name when selected ("enlarged"), plain otherwise
    std::string name = o.name;
    if (on) {
        std::string spaced;
        for (char c : name) { spaced += c; spaced += ' '; }
        spaced.pop_back();
        name = spaced;
        attron(attr | A_REVERSE);
        mvhline(r.y + 1, r.x + 1, ' ', r.w - 2);
        attroff(A_REVERSE);
        centered(r.y + 1, r.x, r.w, name, attr | A_REVERSE);
        attroff(attr);
    } else {
        centered(r.y + 1, r.x, r.w, name + "  -  " + o.tag, attr);
    }

    if (!on || r.h < 6) return;
    // description (clipped while the button is still animating open)
    auto lines = wrap(o.desc, r.w - 4);
    for (size_t k = 0; k < lines.size(); ++k) {
        int row = r.y + 3 + static_cast<int>(k);
        if (row >= r.y + r.h - 1) break;
        mvaddnstr(row, r.x + 2, lines[k].c_str(), r.w - 4);
    }
    // boot button only once fully open
    if (r.h >= targetHeight(i, sel)) {
        int by = r.y + r.h - 4, bw = std::min(r.w - 6, 34), bx = r.x + (r.w - bw) / 2;
        attron(attr);
        box(by, bx, 3, bw);
        attroff(attr);
        centered(by + 1, bx, bw, std::string(">>  BOOT ") + o.name + "  <<", attr | A_BOLD);
    }
}

void layout(int sel, int top) {
    int y = top, w = btnWidth(), x = (COLS - w) / 2;
    for (int i = 0; i < N; ++i) {
        rects[i] = {y, x, static_cast<int>(curH[i] + 0.5f), w};
        y += rects[i].h + 1;
    }
    (void)sel;
}

int hit(int y, int x) {
    for (int i = 0; i < N; ++i) {
        const Rect &r = rects[i];
        if (y >= r.y && y < r.y + r.h && x >= r.x && x < r.x + r.w) return i;
    }
    return -1;
}

// ---- loading sequence --------------------------------------------------------
void loading(int idx) {
    const OsInfo &o = OSES[idx];
    const char spin[] = "|/-\\";
    int pct = 0, tick = 0;
    timeout(0);
    while (pct < 100) {
        pct = std::min(100, pct + 1 + std::rand() % 3);
        erase();
        int top = drawTitle();
        int attr = COLOR_PAIR(o.color) | A_BOLD;
        int mid = std::max(top + 1, LINES / 2 - 3);
        centered(mid, 0, COLS, std::string("Booting ") + o.name + " " + spin[tick++ % 4], attr);
        size_t si = std::min(o.stages.size() - 1, static_cast<size_t>(pct) * o.stages.size() / 101);
        centered(mid + 2, 0, COLS, std::string(o.stages[si]) + "...", COLOR_PAIR(5));
        int bw = std::max(10, std::min(COLS - 8, 50)), filled = pct * bw / 100;
        std::string bar = "[" + std::string(filled, '#') + std::string(bw - filled, '-') + "]";
        centered(mid + 4, 0, COLS, bar, attr);
        centered(mid + 5, 0, COLS, std::to_string(pct) + "%", attr);
        refresh();
        napms(35 + std::rand() % 45);
    }
    centered(LINES / 2 + 4, 0, COLS, "Ready.", COLOR_PAIR(o.color) | A_BOLD);
    refresh();
    napms(300);
    flushinp();
    timeout(40);
}

}  // namespace

int main() {
    std::setlocale(LC_ALL, "");
    std::srand(static_cast<unsigned>(nowMs()));
    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);
    mouseinterval(0);                       // raw press events: faster taps
    mousemask(ALL_MOUSE_EVENTS, nullptr);
    if (has_colors()) {
        start_color();
        use_default_colors();
        init_pair(1, COLOR_GREEN, -1);
        init_pair(2, COLOR_CYAN, -1);
        init_pair(3, COLOR_MAGENTA, -1);
        init_pair(4, COLOR_YELLOW, -1);
        init_pair(5, COLOR_WHITE, -1);
    }
    timeout(40);                            // ~25 fps animation tick

    int sel = -1, rc = 0;
    long lastTap = 0;
    bool running = true;

    auto launch = [&](int i) {
        loading(i);
        rc = 10 + i;
        running = false;
    };

    while (running) {
        erase();
        int top = drawTitle();
        for (int i = 0; i < N; ++i) {       // animate heights towards target
            float t = static_cast<float>(targetHeight(i, sel));
            if (curH[i] < t) curH[i] = std::min(t, curH[i] + 1.5f);
            else if (curH[i] > t) curH[i] = std::max(t, curH[i] - 1.5f);
        }
        layout(sel, top);
        for (int i = 0; i < N; ++i) drawButton(i, sel);
        centered(LINES - 1, 0, COLS, sel < 0 ? "Tap an OS to select  |  q = quit"
                                              : "Tap again or Enter to boot  |  q = quit", COLOR_PAIR(5));
        refresh();

        int ch = getch();
        if (ch == ERR) continue;
        switch (ch) {
            case KEY_MOUSE: {
                MEVENT ev;
                if (getmouse(&ev) != OK) break;
                if (ev.bstate & (BUTTON4_PRESSED)) { sel = (sel <= 0) ? N - 1 : sel - 1; break; }
                if (ev.bstate & (BUTTON5_PRESSED)) { sel = (sel + 1) % N; break; }
                if (!(ev.bstate & (BUTTON1_PRESSED | BUTTON1_CLICKED | BUTTON1_DOUBLE_CLICKED))) break;
                long t = nowMs();
                if (t - lastTap < 250) break;           // debounce press+click pairs
                lastTap = t;
                int i = hit(ev.y, ev.x);
                if (i < 0) break;
                if (i == sel) launch(i); else sel = i;
                break;
            }
            case KEY_UP: case 'k': sel = (sel <= 0) ? N - 1 : sel - 1; break;
            case KEY_DOWN: case 'j': case '\t': sel = (sel + 1) % N; break;
            case '1': case '2': case '3': sel = ch - '1'; break;
            case '\n': case '\r': case KEY_ENTER:
                if (sel < 0) sel = 0; else launch(sel);
                break;
            case 'q': case 'Q': case 27: running = false; break;
            case KEY_RESIZE: clear(); break;
            default: break;
        }
    }
    endwin();
    return rc;
}
