/*
 * popsys.c - low-level "firmware / bootloader" simulation (plain C).
 * Prints a GRUB-style menu (linux), a UEFI + memory test screen (windows) or
 * an EFI/Darwin boot banner (mac) before the OS shell starts.
 * Usage: popsys <linux|windows|mac>      (set POP_FAST=1 to skip delays)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int fast;
static void ms(int m) { if (!fast) usleep((useconds_t)m * 1000); }

static void memtest(const char *label, int total_mb) {
    for (int mb = 0; mb <= total_mb; mb += total_mb / 16) {
        printf("\r  %s %5d MB  OK", label, mb);
        fflush(stdout);
        ms(30);
    }
    printf("\n");
}

static void grub(void) {
    printf("\033[2J\033[H");
    printf("   GNU GRUB  version 2.12-pop\n\n");
    printf(" +--------------------------------------------------+\n");
    printf(" |\033[7m*POP Linux 1.0 (Aurora)                           \033[0m|\n");
    printf(" | Advanced options for POP Linux                   |\n");
    printf(" | UEFI Firmware Settings                           |\n");
    printf(" +--------------------------------------------------+\n\n");
    for (int s = 2; s > 0; --s) {
        printf("\r   The highlighted entry will be executed automatically in %ds.", s);
        fflush(stdout);
        ms(500);
    }
    printf("\n\n   Loading Linux 6.1.0-pop ...\n   Loading initial ramdisk ...\n");
    ms(300);
}

static void uefi(void) {
    printf("\033[2J\033[H");
    printf("POP UEFI Firmware v1.0   (C) POP Project\n");
    printf("CPU: ARM64 Virtual Processor, 8 cores\n");
    memtest("Memory test:", 8192);
    printf("  Boot device : NVMe0 (Windows Boot Manager)\n");
    ms(300);
    printf("  Secure Boot : enabled\n  Starting Windows Boot Manager...\n");
    ms(400);
}

static void efi_mac(void) {
    printf("\033[2J\033[H");
    printf("EFI Boot Manager - Darwin\n");
    printf("  boot-args    : (none)\n  Kernel cache : /System/Library/Caches/com.apple.kernelcaches/kernelcache\n");
    memtest("Memory map  :", 8192);
    printf("  Verifying system volume seal... OK\n");
    ms(400);
}

int main(int argc, char **argv) {
    const char *os = argc > 1 ? argv[1] : "linux";
    fast = getenv("POP_FAST") != NULL;
    if (!strcmp(os, "linux")) grub();
    else if (!strcmp(os, "windows")) uefi();
    else if (!strcmp(os, "mac")) efi_mac();
    else { fprintf(stderr, "usage: popsys <linux|windows|mac>\n"); return 2; }
    printf("\033[2J\033[H");
    return 0;
}
