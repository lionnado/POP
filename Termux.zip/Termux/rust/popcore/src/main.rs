//! popcore - process table, scheduler simulation and registry hive for POP.
//! Protocol (stdin/stdout): one tab-separated request per line; the reply is
//! zero or more lines followed by a line containing only ".".
//! Standard library only, so it builds offline inside Termux.

use std::collections::BTreeMap;
use std::fs;
use std::io::{self, BufRead, Write};

const TOTAL_KB: u64 = 8 * 1024 * 1024;
const BASE_USED_KB: u64 = 1_100_000;

struct Proc {
    pid: u32,
    ppid: u32,
    state: char,
    mem: u64,
    name: String,
    prot: bool,
}

struct Key {
    disp: String,
    // upper-case value name -> (name, type, data)
    vals: BTreeMap<String, (String, String, String)>,
}

struct Core {
    procs: Vec<Proc>,
    next: u32,
    step: u32,
    nprot: usize,
    seed: u64,
    reg: BTreeMap<String, Key>,
}

fn field<'a>(f: &[&'a str], i: usize) -> &'a str {
    f.get(i).copied().unwrap_or("")
}

impl Core {
    fn new() -> Self {
        Core { procs: Vec::new(), next: 1, step: 1, nprot: 0, seed: 0x9E37_79B9_7F4A_7C15, reg: BTreeMap::new() }
    }

    /// Small LCG: deterministic "scheduler" noise without external crates.
    fn rand(&mut self) -> u64 {
        self.seed = self.seed.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        self.seed >> 33
    }

    fn tick(&mut self) {
        for i in 0..self.procs.len() {
            let r = self.rand();
            let p = &mut self.procs[i];
            if r % 5 == 0 {
                p.state = if p.state == 'R' { 'S' } else { 'R' };
            }
            let j = r % 64;
            p.mem = if r % 2 == 0 { p.mem + j } else { p.mem.saturating_sub(j).max(256) };
        }
    }

    fn ensure_key(&mut self, key: &str) {
        let parts: Vec<&str> = key.split('\\').collect();
        for i in 1..=parts.len() {
            let k = parts[..i].join("\\");
            let disp = k.clone();
            self.reg.entry(k.to_uppercase()).or_insert_with(|| Key { disp, vals: BTreeMap::new() });
        }
    }

    fn add_value(&mut self, key: &str, name: &str, ty: &str, data: &str) {
        self.ensure_key(key);
        if !name.is_empty() {
            if let Some(k) = self.reg.get_mut(&key.to_uppercase()) {
                k.vals.insert(name.to_uppercase(), (name.to_string(), ty.to_string(), data.to_string()));
            }
        }
    }

    fn handle(&mut self, line: &str) -> String {
        let f: Vec<&str> = line.split('\t').collect();
        match f[0] {
            "INIT" => {
                self.step = field(&f, 1).parse().unwrap_or(1);
                self.next = field(&f, 2).parse().unwrap_or(1);
                self.nprot = field(&f, 3).parse().unwrap_or(0);
                self.procs.clear();
                "ok".to_string()
            }
            "SPAWN" => {
                let pid = self.next;
                self.next += self.step;
                let prot = self.procs.len() < self.nprot;
                self.procs.push(Proc {
                    pid,
                    ppid: field(&f, 1).parse().unwrap_or(0),
                    state: 'S',
                    mem: field(&f, 2).parse().unwrap_or(1024),
                    name: field(&f, 3).to_string(),
                    prot,
                });
                pid.to_string()
            }
            "KILL" => {
                let pid: u32 = field(&f, 1).parse().unwrap_or(u32::MAX);
                match self.procs.iter().position(|p| p.pid == pid) {
                    Some(i) => {
                        if self.procs[i].prot {
                            "err\tprotected".to_string()
                        } else {
                            self.procs.remove(i);
                            "ok".to_string()
                        }
                    }
                    None => "err\tnotfound".to_string(),
                }
            }
            "PS" => {
                self.tick();
                self.procs
                    .iter()
                    .map(|p| format!("{}\t{}\t{}\t{}\t{}", p.pid, p.ppid, p.state, p.mem, p.name))
                    .collect::<Vec<_>>()
                    .join("\n")
            }
            "MEM" => {
                let used = BASE_USED_KB + self.procs.iter().map(|p| p.mem).sum::<u64>();
                format!("{}\t{}\t{}", TOTAL_KB, used, TOTAL_KB.saturating_sub(used))
            }
            "REGADD" => {
                self.add_value(field(&f, 1), field(&f, 2), field(&f, 3), field(&f, 4));
                "ok".to_string()
            }
            "REGDEL" => {
                let ku = field(&f, 1).to_uppercase();
                let name = field(&f, 2);
                if !name.is_empty() {
                    let removed = self.reg.get_mut(&ku).map(|k| k.vals.remove(&name.to_uppercase()).is_some()).unwrap_or(false);
                    return if removed { "ok".to_string() } else { "err".to_string() };
                }
                let prefix = format!("{}\\", ku);
                let victims: Vec<String> = self.reg.keys().filter(|k| k.as_str() == ku || k.starts_with(&prefix)).cloned().collect();
                if victims.is_empty() {
                    return "err".to_string();
                }
                for v in victims {
                    self.reg.remove(&v);
                }
                "ok".to_string()
            }
            "REGQ" => {
                let ku = field(&f, 1).to_uppercase();
                let key = match self.reg.get(&ku) {
                    Some(k) => k,
                    None => return "err".to_string(),
                };
                let mut out: Vec<String> = key.vals.values().map(|(n, t, d)| format!("V\t{}\t{}\t{}", n, t, d)).collect();
                let prefix = format!("{}\\", ku);
                for (k, v) in self.reg.range(prefix.clone()..) {
                    if !k.starts_with(&prefix) {
                        break;
                    }
                    if !k[prefix.len()..].contains('\\') {
                        out.push(format!("K\t{}", v.disp));
                    }
                }
                out.join("\n")
            }
            "REGSAVE" => {
                let mut s = String::new();
                for k in self.reg.values() {
                    if k.vals.is_empty() {
                        s.push_str(&format!("{}\t\t\t\n", k.disp));
                    }
                    for (n, t, d) in k.vals.values() {
                        s.push_str(&format!("{}\t{}\t{}\t{}\n", k.disp, n, t, d.replace(['\t', '\n'], " ")));
                    }
                }
                if fs::write(field(&f, 1), s).is_ok() { "ok".to_string() } else { "err".to_string() }
            }
            "REGLOAD" => match fs::read_to_string(field(&f, 1)) {
                Ok(text) => {
                    self.reg.clear();
                    for l in text.lines() {
                        let p: Vec<&str> = l.splitn(4, '\t').collect();
                        if p.is_empty() || p[0].is_empty() {
                            continue;
                        }
                        self.add_value(p[0], field(&p, 1), field(&p, 2), field(&p, 3));
                    }
                    "ok".to_string()
                }
                Err(_) => "err".to_string(),
            },
            _ => "err\tunknown".to_string(),
        }
    }
}

fn main() {
    if std::env::args().nth(1).as_deref() != Some("serve") {
        eprintln!("popcore: internal engine for POP. Usage: popcore serve");
        std::process::exit(2);
    }
    let mut core = Core::new();
    let stdin = io::stdin();
    let mut out = io::stdout();
    for line in stdin.lock().lines() {
        let line = match line {
            Ok(l) => l,
            Err(_) => break,
        };
        if line.is_empty() {
            continue;
        }
        let resp = core.handle(&line);
        if writeln!(out, "{}\n.", resp).is_err() {
            break;
        }
        let _ = out.flush();
    }
}
